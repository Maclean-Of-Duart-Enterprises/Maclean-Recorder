/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.content.Context
import android.media.AudioDeviceInfo
import android.media.MediaRecorder
import android.os.Build
import com.macleanofduartenterprises.macleanrecorder.data.*
import java.io.File

class PlatformRecorder(private val context: Context) {
    private var recorder: MediaRecorder? = null
    fun start(file: File, settings: RecorderSettings, source: Int, device: AudioDeviceInfo? = null,
              onError: (Throwable) -> Unit) {
        val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()
        recorder = r
        try {
            r.setAudioSource(source)
            when (settings.format) {
                AudioFormat.M4A -> { r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC) }
                AudioFormat.OPUS -> {
                    if (Build.VERSION.SDK_INT < 29) error("Opus/Ogg requires Android 10 or later.")
                    r.setOutputFormat(MediaRecorder.OutputFormat.OGG); r.setAudioEncoder(MediaRecorder.AudioEncoder.OPUS)
                }
                else -> error("Unsupported platform recording format.")
            }
            if (device != null) {
                if (Build.VERSION.SDK_INT < 28) error("Explicit input routing for this format requires Android 9 or later. Use WAV or FLAC on Android 8.")
                check(r.setPreferredDevice(device)) { "The selected input could not be routed." }
            }
            r.setAudioChannels(settings.channels.count); r.setAudioSamplingRate(settings.sampleRate)
            r.setAudioEncodingBitRate(settings.bitrate); r.setOutputFile(file.absolutePath)
            r.setOnErrorListener { _, what, extra -> onError(IllegalStateException("Audio encoder error ($what, $extra).")) }
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED || what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED)
                    onError(IllegalStateException("The device recording limit was reached."))
            }
            r.prepare(); r.start()
        } catch (t: Exception) { r.release(); recorder = null; throw t }
    }
    fun amplitude(): Float = runCatching { (recorder?.maxAmplitude ?: 0) / 32768f }.getOrDefault(0f)
    fun stop() {
        val r = recorder ?: return
        recorder = null
        try { r.stop() } finally { r.release() }
    }
}
