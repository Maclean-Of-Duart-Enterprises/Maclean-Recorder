/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.macleanofduartenterprises.macleanrecorder.MainActivity
import com.macleanofduartenterprises.macleanrecorder.audio.AudioInputManager
import com.macleanofduartenterprises.macleanrecorder.audio.AudioRoutingManager
import com.macleanofduartenterprises.macleanrecorder.audio.PcmRecorder
import com.macleanofduartenterprises.macleanrecorder.data.AudioFormat
import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import com.macleanofduartenterprises.macleanrecorder.data.InputChoice
import com.macleanofduartenterprises.macleanrecorder.data.RecorderSettings
import com.macleanofduartenterprises.macleanrecorder.data.RecordingRepository
import com.macleanofduartenterprises.macleanrecorder.data.RecordingSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Owns capture for the lifetime of the foreground service, independently of any screen. */
class RecordingService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val commands = Mutex()
    private lateinit var routing: AudioRoutingManager
    private lateinit var repository: RecordingRepository
    private var recorder: PcmRecorder? = null
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var activeFile: File? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        routing = AudioRoutingManager(this)
        repository = RecordingRepository.get(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "Audio recording", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (recording.value) {
                    busy.value = false
                    return START_NOT_STICKY
                }
                try {
                    check(
                        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                            PackageManager.PERMISSION_GRANTED
                    ) { "Allow microphone and audio-recording permission first." }
                    val settings = RecorderSettings(
                        format = AudioFormat.valueOf(intent.getStringExtra(EXTRA_FORMAT) ?: AudioFormat.MP3.name),
                        channels = ChannelMode.valueOf(intent.getStringExtra(EXTRA_CHANNELS) ?: ChannelMode.MONO.name),
                        sampleRate = intent.getIntExtra(EXTRA_RATE, 48000),
                        bitrate = intent.getIntExtra(EXTRA_BITRATE, 192000),
                        recordingSource = RecordingSource.valueOf(
                            intent.getStringExtra(EXTRA_RECORDING_SOURCE) ?: RecordingSource.MICROPHONE.name
                        ),
                        input = InputChoice.valueOf(
                            intent.getStringExtra(EXTRA_INPUT) ?: InputChoice.SYSTEM_DEFAULT.name
                        ),
                        noiseSuppression = intent.getBooleanExtra(EXTRA_NOISE_SUPPRESSION, false),
                        equalizerEnabled = intent.getBooleanExtra(EXTRA_EQUALIZER, false)
                    )
                    showNotification(settings.recordingSource)
                    val projectionResultCode = intent.getIntExtra(EXTRA_PROJECTION_RESULT_CODE, Activity.RESULT_CANCELED)
                    val projectionData = if (Build.VERSION.SDK_INT >= 33) {
                        intent.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(EXTRA_PROJECTION_DATA)
                    }
                    scope.launch {
                        commands.withLock { begin(settings, projectionResultCode, projectionData) }
                    }
                } catch (t: Throwable) {
                    error.value = t.message ?: "The recording service could not start."
                    busy.value = false
                    ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
            ACTION_STOP -> scope.launch { commands.withLock { finishRecording() } }
            else -> if (!recording.value) {
                busy.value = false
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    @SuppressLint("WakelockTimeout") // User-controlled session; every stop/failure/onDestroy releases it.
    private suspend fun begin(settings: RecorderSettings, projectionResultCode: Int, projectionData: Intent?) {
        if (recording.value) {
            busy.value = false
            return
        }
        busy.value = true
        try {
            wakeLock = getSystemService(PowerManager::class.java)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "$packageName:recording")
                .apply { acquire() }

            val activeProjection = if (settings.recordingSource.usesDeviceAudio) {
                check(Build.VERSION.SDK_INT >= 29) { "Device audio capture requires Android 10 or later." }
                check(projectionResultCode == Activity.RESULT_OK && projectionData != null) {
                    "Approve the Android device-audio capture prompt first."
                }
                getSystemService(MediaProjectionManager::class.java)
                    .getMediaProjection(projectionResultCode, projectionData)
                    .also { mediaProjection ->
                        val callback = object : MediaProjection.Callback() {
                            override fun onStop() {
                                error.value = "Device audio permission ended. The recording was saved."
                                scope.launch { commands.withLock { if (recording.value) finishRecording() } }
                            }
                        }
                        projectionCallback = callback
                        mediaProjection.registerCallback(callback, Handler(Looper.getMainLooper()))
                        projection = mediaProjection
                    }
            } else null

            withContext(Dispatchers.IO) {
                val microphoneDevice = if (settings.recordingSource.usesMicrophone) {
                    routing.apply(settings.input)
                } else null
                val microphoneSource = AudioInputManager.source(settings.input)
                val name = "Recording_" +
                    SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + "_" +
                    UUID.randomUUID().toString().take(8)
                val file = File(repository.directory(), "$name.${settings.format.extension}")
                activeFile = file
                repository.activePath = file.absolutePath
                val failed: (Throwable) -> Unit = { throwable ->
                    scope.launch {
                        commands.withLock {
                            error.value = throwable.message ?: "Audio capture failed."
                            finishRecording()
                        }
                    }
                }
                recorder = PcmRecorder(this@RecordingService).also { engine ->
                    engine.start(
                        file,
                        settings,
                        microphoneSource,
                        microphoneDevice,
                        activeProjection,
                        failed
                    ) { value -> amplitude.value = value }
                }
            }
            recording.value = true
            activeSettings.value = settings
        } catch (t: Throwable) {
            error.value = t.message ?: "Recording could not start."
            withContext(Dispatchers.IO) {
                stopEngine()
                activeFile?.delete()
                activeFile = null
                repository.activePath = null
                repository.refresh()
            }
            releaseProjection()
            releaseWakeLock()
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        } finally {
            busy.value = false
        }
    }

    private suspend fun finishRecording() {
        busy.value = true
        try {
            withContext(Dispatchers.IO) {
                stopEngine()
                activeFile = null
                repository.activePath = null
                repository.refresh()
            }
        } catch (t: Throwable) {
            error.value = t.message ?: "The recording could not be finalized."
        } finally {
            releaseProjection()
            releaseWakeLock()
            recording.value = false
            busy.value = false
            amplitude.value = 0f
            activeSettings.value = null
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopEngine() {
        runCatching { recorder?.stop() }
            .onFailure { error.value = it.message ?: "The recording could not be finalized." }
        recorder = null
        routing.clear()
    }

    private fun releaseProjection() {
        val activeProjection = projection
        val callback = projectionCallback
        if (activeProjection != null && callback != null) {
            runCatching { activeProjection.unregisterCallback(callback) }
        }
        projectionCallback = null
        projection = null
        runCatching { activeProjection?.stop() }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    private fun showNotification(source: RecordingSource) {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, RecordingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Maclean Recorder")
            .setContentText("Recording ${source.label.lowercase()} — tap Stop to save")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Stop and save", stop)
            .build()

        var types = 0
        if (Build.VERSION.SDK_INT >= 29 && source.usesDeviceAudio) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        if (Build.VERSION.SDK_INT >= 30 && source.usesMicrophone) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, types)
    }

    override fun onDestroy() {
        stopEngine()
        releaseProjection()
        releaseWakeLock()
        scope.cancel()
        repository.activePath = null
        recording.value = false
        busy.value = false
        amplitude.value = 0f
        activeSettings.value = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val CHANNEL = "recording"
        private const val NOTIFICATION_ID = 101
        private const val ACTION_START = "com.macleanofduartenterprises.macleanrecorder.START"
        private const val ACTION_STOP = "com.macleanofduartenterprises.macleanrecorder.STOP"
        private const val EXTRA_FORMAT = "format"
        private const val EXTRA_CHANNELS = "channels"
        private const val EXTRA_RATE = "rate"
        private const val EXTRA_BITRATE = "bitrate"
        private const val EXTRA_RECORDING_SOURCE = "recording_source"
        private const val EXTRA_INPUT = "input"
        private const val EXTRA_NOISE_SUPPRESSION = "ns"
        private const val EXTRA_EQUALIZER = "eq"
        private const val EXTRA_PROJECTION_RESULT_CODE = "projection_result_code"
        private const val EXTRA_PROJECTION_DATA = "projection_data"

        val recording = MutableStateFlow(false)
        val busy = MutableStateFlow(false)
        val amplitude = MutableStateFlow(0f)
        val error = MutableStateFlow<String?>(null)
        val activeSettings = MutableStateFlow<RecorderSettings?>(null)

        fun start(
            context: Context,
            settings: RecorderSettings,
            projectionResultCode: Int? = null,
            projectionData: Intent? = null
        ) {
            if (recording.value || !busy.compareAndSet(false, true)) return
            error.value = null
            try {
                val intent = Intent(context, RecordingService::class.java)
                    .setAction(ACTION_START)
                    .putExtra(EXTRA_FORMAT, settings.format.name)
                    .putExtra(EXTRA_CHANNELS, settings.channels.name)
                    .putExtra(EXTRA_RATE, settings.sampleRate)
                    .putExtra(EXTRA_BITRATE, settings.bitrate)
                    .putExtra(EXTRA_RECORDING_SOURCE, settings.recordingSource.name)
                    .putExtra(EXTRA_INPUT, settings.input.name)
                    .putExtra(EXTRA_NOISE_SUPPRESSION, settings.noiseSuppression)
                    .putExtra(EXTRA_EQUALIZER, settings.equalizerEnabled)
                if (projectionResultCode != null && projectionData != null) {
                    intent.putExtra(EXTRA_PROJECTION_RESULT_CODE, projectionResultCode)
                    intent.putExtra(EXTRA_PROJECTION_DATA, projectionData)
                }
                ContextCompat.startForegroundService(context, intent)
            } catch (t: Throwable) {
                busy.value = false
                error.value = t.message ?: "Cannot start the recording service."
            }
        }

        fun stop(context: Context) {
            if (!recording.value || !busy.compareAndSet(false, true)) return
            try {
                context.startService(Intent(context, RecordingService::class.java).setAction(ACTION_STOP))
            } catch (t: Throwable) {
                busy.value = false
                error.value = t.message ?: "Cannot stop the recording service."
            }
        }
    }
}
