/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.catch
import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import java.io.IOException

private val Context.ds by preferencesDataStore("recorder_settings", corruptionHandler = ReplaceFileCorruptionHandler { emptyPreferences() })
class SettingsStore(private val context: Context) {
    private object K {
        val format=stringPreferencesKey("format"); val channels=stringPreferencesKey("channels"); val rate=intPreferencesKey("rate")
        val bitrate=intPreferencesKey("bitrate"); val source=stringPreferencesKey("recording_source"); val input=stringPreferencesKey("input"); val bg=stringPreferencesKey("bg"); val bgColor=stringPreferencesKey("bg_color")
        val buttonColor=stringPreferencesKey("button_color"); val lineColor=stringPreferencesKey("line_color"); val letterColor=stringPreferencesKey("letter_color"); val opacity=floatPreferencesKey("opacity")
        val scale=floatPreferencesKey("scale"); val contrast=booleanPreferencesKey("contrast"); val screen=booleanPreferencesKey("screen")
        val ns=booleanPreferencesKey("ns"); val eq=booleanPreferencesKey("eq")
        val defaultsVersion=intPreferencesKey("defaults_version")
    }
    val flow: Flow<RecorderSettings> = context.ds.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            RecorderSettings(
                format = AudioFormat.entries.firstOrNull { it.name == p[K.format] } ?: AudioFormat.MP3,
                channels = ChannelMode.entries.firstOrNull { it.name == p[K.channels] } ?: ChannelMode.MONO,
                sampleRate = (p[K.rate] ?: 48000).coerceIn(8000, 96000),
                bitrate = (p[K.bitrate] ?: 192000).coerceIn(64000, 320000),
                recordingSource = RecordingSource.entries.firstOrNull { it.name == p[K.source] }
                    ?: RecordingSource.MICROPHONE,
                input = InputChoice.entries.firstOrNull { it.name == p[K.input] }
                    ?: InputChoice.SYSTEM_DEFAULT,
                backgroundUri = p[K.bg] ?: "",
                backgroundColorHex = AppearanceColors.normalize(p[K.bgColor], AppearanceColors.BACKGROUND),
                buttonColorHex = AppearanceColors.normalize(p[K.buttonColor], AppearanceColors.BUTTON),
                lineColorHex = AppearanceColors.normalize(p[K.lineColor], AppearanceColors.LINE),
                letterColorHex = AppearanceColors.normalize(p[K.letterColor], AppearanceColors.LETTER),
                backgroundOpacity = (p[K.opacity]?.takeIf { it.isFinite() } ?: .12f).coerceIn(0f, 1f),
                textScale = (p[K.scale]?.takeIf { it.isFinite() } ?: 1f).coerceIn(.8f, 1.8f),
                highContrast = p[K.contrast] ?: false,
                keepScreenOn = p[K.screen] ?: false,
                noiseSuppression = p[K.ns] ?: false,
                equalizerEnabled = p[K.eq] ?: false
            )
        }
    /** Applies new defaults without overwriting choices the user explicitly saved. */
    suspend fun migrateDefaults() = context.ds.edit { p ->
        if ((p[K.defaultsVersion] ?: 0) < 2) {
            if (p[K.format] == null) p[K.format] = AudioFormat.MP3.name
        }
        if ((p[K.defaultsVersion] ?: 0) < 3) {
            if (p[K.buttonColor] == null) p[K.buttonColor] = AppearanceColors.BUTTON
            if (p[K.lineColor] == null) p[K.lineColor] = AppearanceColors.LINE
            if (p[K.letterColor] == null) p[K.letterColor] = AppearanceColors.LETTER
        }
        p[K.defaultsVersion] = 3
    }
    suspend fun save(s: RecorderSettings) = context.ds.edit { p ->
        p[K.format]=s.format.name; p[K.channels]=s.channels.name; p[K.rate]=s.sampleRate; p[K.bitrate]=s.bitrate; p[K.source]=s.recordingSource.name; p[K.input]=s.input.name
        p[K.bg]=s.backgroundUri; p[K.bgColor]=AppearanceColors.normalize(s.backgroundColorHex, AppearanceColors.BACKGROUND)
        p[K.buttonColor]=AppearanceColors.normalize(s.buttonColorHex, AppearanceColors.BUTTON); p[K.lineColor]=AppearanceColors.normalize(s.lineColorHex, AppearanceColors.LINE)
        p[K.letterColor]=AppearanceColors.normalize(s.letterColorHex, AppearanceColors.LETTER); p[K.opacity]=s.backgroundOpacity; p[K.scale]=s.textScale; p[K.contrast]=s.highContrast; p[K.screen]=s.keepScreenOn
        p[K.ns]=s.noiseSuppression; p[K.eq]=s.equalizerEnabled; p[K.defaultsVersion]=3
    }
}
