/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.macleanofduartenterprises.macleanrecorder.data.*
import com.macleanofduartenterprises.macleanrecorder.service.RecordingService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class RecorderViewModel(app: Application) : AndroidViewModel(app) {
    private val settingsStore = SettingsStore(app)
    private val repo = RecordingRepository.get(app)
    val settings = settingsStore.flow.stateIn(viewModelScope, SharingStarted.Eagerly, RecorderSettings())
    val recordings = repo.items
    val recording = RecordingService.recording
    val busy = RecordingService.busy
    val amplitude = RecordingService.amplitude
    val error = RecordingService.error
    val activeSettings = RecordingService.activeSettings
    init {
        viewModelScope.launch { settingsStore.migrateDefaults() }
        runIo { repo.refresh() }
    }
    private fun runIo(action: () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        runCatching(action).onFailure { error.value = it.message ?: "The operation failed." }
    }
    fun save(settings: RecorderSettings) = viewModelScope.launch {
        runCatching { settingsStore.save(settings) }.onFailure { error.value = "Settings could not be saved: ${it.message}" }
    }
    fun clearError() { error.value = null }
    fun showError(message: String) { error.value = message }
    fun start(projectionResultCode: Int? = null, projectionData: Intent? = null) =
        RecordingService.start(getApplication(), settings.value, projectionResultCode, projectionData)
    fun stop() = RecordingService.stop(getApplication())
    fun delete(ids: Set<String>) = runIo { repo.delete(ids) }
    fun favorite(id: String) = runIo { repo.favorite(id) }
    fun editMetadata(id: String, title: String, folder: String, tags: Set<String>) = runIo { repo.editMetadata(id, title, folder, tags) }
    fun trimWav(id: String, startMs: Long, endMs: Long, replace: Boolean) = runIo {
        repo.trimWav(id, startMs, endMs, replace)
    }
}
