/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.macleanofduartenterprises.macleanrecorder.data.InputChoice
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class AudioRoutingManager(private val context: Context) {
    private val manager = context.getSystemService(AudioManager::class.java)
    private var previousMode: Int? = null
    private var changedRoute = false
    private var startedSco = false

    @Suppress("DEPRECATION")
    fun apply(choice: InputChoice): AudioDeviceInfo? {
        if (choice == InputChoice.SYSTEM_DEFAULT) return null
        if (choice == InputChoice.BUILT_IN_MIC) return manager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
            ?: error("No built-in microphone is available.")
        if (Build.VERSION.SDK_INT >= 31) {
            check(ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                "Allow Nearby devices permission to record from Bluetooth."
            }
            val device = manager.availableCommunicationDevices.firstOrNull {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
            } ?: error("Connect a Bluetooth headset with a microphone first.")
            previousMode = manager.mode
            manager.mode = AudioManager.MODE_IN_COMMUNICATION
            changedRoute = manager.setCommunicationDevice(device)
            check(changedRoute) { "Android could not activate the Bluetooth microphone." }
        } else {
            check(manager.isBluetoothScoAvailableOffCall) { "Bluetooth microphone capture is unavailable on this device." }
            val ready = CountDownLatch(1)
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    if (intent?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1) == AudioManager.SCO_AUDIO_STATE_CONNECTED) ready.countDown()
                }
            }
            ContextCompat.registerReceiver(context, receiver, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED), ContextCompat.RECEIVER_EXPORTED)
            try {
                previousMode = manager.mode
                manager.mode = AudioManager.MODE_IN_COMMUNICATION
                startedSco = true; manager.startBluetoothSco()
                check(ready.await(6, TimeUnit.SECONDS)) { "The Bluetooth microphone did not connect. Check the headset and try again." }
                manager.isBluetoothScoOn = true
            } finally { context.unregisterReceiver(receiver) }
        }
        // Communication routing chooses the actual SCO/BLE input. Prefer it when exposed as a source.
        return manager.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull {
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || (Build.VERSION.SDK_INT >= 31 && it.type == AudioDeviceInfo.TYPE_BLE_HEADSET)
        }
    }

    @Suppress("DEPRECATION")
    fun clear() {
        if (Build.VERSION.SDK_INT >= 31 && changedRoute) runCatching { manager.clearCommunicationDevice() }
        if (startedSco) runCatching { manager.isBluetoothScoOn = false; manager.stopBluetoothSco() }
        previousMode?.let { mode -> runCatching { manager.mode = mode } }
        previousMode = null; changedRoute = false; startedSco = false
    }
}
