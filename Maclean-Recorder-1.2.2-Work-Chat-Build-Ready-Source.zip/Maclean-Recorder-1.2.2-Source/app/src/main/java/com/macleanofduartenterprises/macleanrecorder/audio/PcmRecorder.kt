/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat as AndroidAudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.Build
import androidx.annotation.RequiresApi
import com.macleanofduartenterprises.macleanrecorder.data.AudioFormat
import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import com.macleanofduartenterprises.macleanrecorder.data.RecorderSettings
import net.sourceforge.lame.mp3.Lame
import net.sourceforge.lame.mp3.MPEGMode
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.concurrent.thread

/**
 * Captures microphone audio, capturable device playback, or a balanced mix of both.
 * All paths use the same PCM pipeline so every output format behaves consistently.
 */
class PcmRecorder(private val context: Context) {
    @Volatile private var running = false
    @Volatile private var stopping = false
    @Volatile private var failure: Throwable? = null
    private var worker: Thread? = null
    private var records: List<AudioRecord> = emptyList()
    private var readers: List<CaptureReader> = emptyList()
    private var effects: AudioEffects? = null

    @SuppressLint("MissingPermission") // RecordingService checks RECORD_AUDIO before starting capture.
    fun start(
        file: File,
        settings: RecorderSettings,
        microphoneSource: Int,
        microphoneDevice: AudioDeviceInfo?,
        projection: MediaProjection?,
        onError: (Throwable) -> Unit,
        onAmplitude: (Float) -> Unit
    ) {
        check(worker == null) { "A recording is already active." }
        val channelMask = if (settings.channels == ChannelMode.MONO) {
            AndroidAudioFormat.CHANNEL_IN_MONO
        } else {
            AndroidAudioFormat.CHANNEL_IN_STEREO
        }
        val frameBytes = settings.channels.count * 2
        val minimum = AudioRecord.getMinBufferSize(
            settings.sampleRate,
            channelMask,
            AndroidAudioFormat.ENCODING_PCM_16BIT
        )
        require(minimum > 0) { "The selected sample rate and channel count are not supported." }
        val chunkBytes = alignToFrame(maxOf(minimum, 16 * 1024), frameBytes)
        val audioFormat = AndroidAudioFormat.Builder()
            .setEncoding(AndroidAudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(settings.sampleRate)
            .setChannelMask(channelMask)
            .build()

        val opened = mutableListOf<AudioRecord>()
        var openedEffects: AudioEffects? = null
        var sink: PcmSink? = null
        try {
            if (settings.recordingSource.usesMicrophone) {
                val microphone = AudioRecord.Builder()
                    .setAudioSource(microphoneSource)
                    .setAudioFormat(audioFormat)
                    .setBufferSizeInBytes(chunkBytes * 4)
                    .build()
                check(microphone.state == AudioRecord.STATE_INITIALIZED) { "Microphone initialization failed." }
                if (microphoneDevice != null) {
                    check(microphone.setPreferredDevice(microphoneDevice)) { "The selected microphone could not be routed." }
                }
                openedEffects = AudioEffects(
                    microphone.audioSessionId,
                    settings.noiseSuppression,
                    settings.equalizerEnabled
                )
                opened += microphone
            }
            if (settings.recordingSource.usesDeviceAudio) {
                if (Build.VERSION.SDK_INT < 29) error("Device audio capture requires Android 10 or later.")
                val activeProjection = projection ?: error("Approve the Android device-audio capture prompt first.")
                val playback = createPlaybackRecord(activeProjection, audioFormat, chunkBytes * 4)
                check(playback.state == AudioRecord.STATE_INITIALIZED) { "Device audio capture could not be initialized." }
                opened += playback
            }
            check(opened.isNotEmpty()) { "Select at least one recording source." }

            sink = createPcmSink(file, settings)
            opened.forEach { record ->
                record.startRecording()
                check(record.recordingState == AudioRecord.RECORDSTATE_RECORDING) { "An audio source could not start." }
            }

            records = opened.toList()
            effects = openedEffects
            stopping = false
            failure = null
            running = true
            val readerFailure = AtomicReference<Throwable?>(null)
            readers = records.mapIndexed { index, record ->
                CaptureReader(record, chunkBytes, frameBytes, "pcm-source-$index", readerFailure) { running }
            }.also { list -> list.forEach(CaptureReader::start) }
            val activeReaders = readers
            val activeRecords = records
            val activeEffects = effects
            val activeSink = sink
            worker = thread(name = "pcm-encoder") {
                var finalFailure: Throwable? = null
                try {
                    val first = FrameStream(activeReaders[0], chunkBytes)
                    val second = activeReaders.getOrNull(1)?.let { FrameStream(it, chunkBytes) }
                    val firstPcm = ByteArray(chunkBytes)
                    val secondPcm = ByteArray(chunkBytes)
                    val mixed = ByteArray(chunkBytes)
                    while (true) {
                        val firstCount = first.read(firstPcm)
                        if (firstCount == 0) break
                        val outputCount = if (second == null) {
                            firstPcm.copyInto(mixed, 0, 0, firstCount)
                            firstCount
                        } else {
                            val secondCount = second.read(secondPcm)
                            if (secondCount == 0) break
                            val count = minOf(firstCount, secondCount)
                            mixPcm16(firstPcm, secondPcm, mixed, count)
                            count
                        }
                        activeSink.write(mixed, outputCount)
                        onAmplitude(pcmPeak(mixed, outputCount))
                    }
                    readerFailure.get()?.let { throw it }
                } catch (t: Throwable) {
                    finalFailure = t
                } finally {
                    running = false
                    activeRecords.forEach { runCatching { it.stop() } }
                    activeReaders.forEach(CaptureReader::interrupt)
                    activeReaders.forEach(CaptureReader::join)
                    runCatching { activeSink.finish() }.onFailure { if (finalFailure == null) finalFailure = it }
                    activeEffects?.close()
                    activeRecords.forEach { runCatching { it.release() } }
                    failure = finalFailure
                    if (finalFailure != null && !stopping) onError(finalFailure!!)
                }
            }
        } catch (t: Throwable) {
            running = false
            opened.forEach { runCatching { it.stop() }; runCatching { it.release() } }
            openedEffects?.close()
            runCatching { sink?.finish() }
            file.delete()
            throw t
        }
    }

    fun stop() {
        val activeWorker = worker ?: return
        stopping = true
        running = false
        records.forEach { runCatching { it.stop() } }
        try {
            activeWorker.join()
            failure?.let { throw it }
        } finally {
            worker = null
            readers = emptyList()
            records = emptyList()
            effects = null
            failure = null
            stopping = false
        }
    }

    private data class Chunk(val bytes: ByteArray?, val end: Boolean = false)

    private class CaptureReader(
        private val record: AudioRecord,
        private val chunkBytes: Int,
        private val frameBytes: Int,
        private val threadName: String,
        private val failure: AtomicReference<Throwable?>,
        private val isRunning: () -> Boolean
    ) {
        val queue = ArrayBlockingQueue<Chunk>(64)
        private var thread: Thread? = null

        fun start() {
            thread = thread(name = threadName) {
                try {
                    while (isRunning()) {
                        val buffer = ByteArray(chunkBytes)
                        val rawCount = record.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                        if (rawCount < 0) {
                            if (isRunning()) error("Audio capture read failed ($rawCount).")
                            break
                        }
                        val count = rawCount - rawCount.mod(frameBytes)
                        if (count > 0) queue.put(Chunk(if (count == buffer.size) buffer else buffer.copyOf(count)))
                    }
                } catch (t: Throwable) {
                    if (isRunning()) failure.compareAndSet(null, t)
                } finally {
                    val end = Chunk(null, end = true)
                    try {
                        while (!queue.offer(end, 100, TimeUnit.MILLISECONDS)) {
                            if (!isRunning()) {
                                queue.clear()
                                queue.offer(end)
                                break
                            }
                        }
                    } catch (_: InterruptedException) {
                        queue.clear()
                        queue.offer(end)
                    }
                }
            }
        }

        fun interrupt() { thread?.interrupt() }
        fun join() { runCatching { thread?.join() }; thread = null }
    }

    private class FrameStream(private val reader: CaptureReader, private val targetBytes: Int) {
        private var current: ByteArray? = null
        private var offset = 0
        private var ended = false

        fun read(destination: ByteArray): Int {
            if (ended) return 0
            var written = 0
            while (written < targetBytes) {
                var data = current
                if (data == null || offset >= data.size) {
                    val next = reader.queue.take()
                    if (next.end) {
                        ended = true
                        break
                    }
                    data = checkNotNull(next.bytes)
                    current = data
                    offset = 0
                }
                val count = minOf(targetBytes - written, data.size - offset)
                data.copyInto(destination, written, offset, offset + count)
                written += count
                offset += count
            }
            return written
        }
    }
}

@RequiresApi(Build.VERSION_CODES.Q)
@SuppressLint("MissingPermission") // RecordingService verifies RECORD_AUDIO before calling PcmRecorder.
private fun createPlaybackRecord(
    projection: MediaProjection,
    audioFormat: AndroidAudioFormat,
    bufferBytes: Int
): AudioRecord {
    val capture = AudioPlaybackCaptureConfiguration.Builder(projection)
        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
        .addMatchingUsage(AudioAttributes.USAGE_GAME)
        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
        .build()
    return AudioRecord.Builder()
        .setAudioFormat(audioFormat)
        .setBufferSizeInBytes(bufferBytes)
        .setAudioPlaybackCaptureConfig(capture)
        .build()
}

internal fun mixPcm16(first: ByteArray, second: ByteArray, output: ByteArray, count: Int) {
    require(count <= first.size && count <= second.size && count <= output.size)
    var index = 0
    while (index + 1 < count) {
        val left = ((first[index].toInt() and 0xff) or (first[index + 1].toInt() shl 8)).toShort().toInt()
        val right = ((second[index].toInt() and 0xff) or (second[index + 1].toInt() shl 8)).toShort().toInt()
        val mixed = (left + right) / 2
        output[index] = mixed.toByte()
        output[index + 1] = (mixed shr 8).toByte()
        index += 2
    }
}

private fun alignToFrame(value: Int, frameBytes: Int): Int =
    maxOf(frameBytes, value / frameBytes * frameBytes)

internal interface PcmSink {
    fun write(pcm: ByteArray, count: Int)
    fun finish()
}

private fun createPcmSink(file: File, settings: RecorderSettings): PcmSink = when (settings.format) {
    AudioFormat.MP3 -> Mp3PcmSink(file, settings.sampleRate, settings.channels, settings.bitrate)
    AudioFormat.WAV -> WavPcmSink(file, settings.sampleRate, settings.channels)
    AudioFormat.FLAC -> CodecPcmSink(file, settings, MediaFormat.MIMETYPE_AUDIO_FLAC)
    AudioFormat.M4A -> CodecPcmSink(file, settings, MediaFormat.MIMETYPE_AUDIO_AAC)
    AudioFormat.OPUS -> {
        check(Build.VERSION.SDK_INT >= 29) { "Opus/Ogg requires Android 10 or later." }
        CodecPcmSink(file, settings, MediaFormat.MIMETYPE_AUDIO_OPUS)
    }
}

internal class Mp3PcmSink(
    file: File,
    sampleRate: Int,
    private val channels: ChannelMode,
    bitrate: Int
) : PcmSink {
    private val output = FileOutputStream(file)
    private val lame = Lame()
    private val encoded = ByteArray(Lame.LAME_MAXMP3BUFFER)
    private var finished = false

    init {
        try {
            val flags = lame.flags
            flags.inNumChannels = channels.count
            flags.inSampleRate = sampleRate
            flags.mode = if (channels == ChannelMode.MONO) MPEGMode.MONO else MPEGMode.JOINT_STEREO
            flags.bitRate = if (sampleRate < 32000) minOf(bitrate / 1000, 160) else bitrate / 1000
            flags.quality = Lame.QUALITY_MIDDLE
            flags.setFindReplayGain(false)
            lame.id3.init(flags)
            flags.setWriteId3tagAutomatic(false)
            check(lame.initParams() >= 0) { "The selected MP3 settings are not supported." }
        } catch (t: Throwable) {
            runCatching { output.close() }
            runCatching { lame.close() }
            throw t
        }
    }

    override fun write(pcm: ByteArray, count: Int) {
        check(!finished)
        val frameBytes = channels.count * 2
        require(count % frameBytes == 0) { "PCM data is not frame aligned." }
        val frames = count / frameBytes
        val left = FloatArray(frames)
        val right = FloatArray(frames)
        var input = 0
        for (frame in 0 until frames) {
            val first = readPcm16(pcm, input).toFloat() * 65536f
            input += 2
            left[frame] = first
            right[frame] = if (channels == ChannelMode.STEREO) {
                readPcm16(pcm, input).toFloat().also { input += 2 } * 65536f
            } else first
        }
        val produced = lame.encodeBuffer(left, right, frames, encoded)
        check(produced >= 0) { "MP3 encoding failed ($produced)." }
        if (produced > 0) output.write(encoded, 0, produced)
    }

    override fun finish() {
        if (finished) return
        finished = true
        var thrown: Throwable? = null
        try {
            val produced = lame.encodeFlush(encoded)
            check(produced >= 0) { "MP3 finalization failed ($produced)." }
            if (produced > 0) output.write(encoded, 0, produced)
            output.fd.sync()
        } catch (t: Throwable) {
            thrown = t
        } finally {
            runCatching { output.close() }.onFailure { failure ->
                if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
            }
            runCatching { lame.close() }.onFailure { failure ->
                if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
            }
        }
        thrown?.let { throw it }
    }
}

private fun readPcm16(buffer: ByteArray, offset: Int): Int =
    ((buffer[offset].toInt() and 0xff) or (buffer[offset + 1].toInt() shl 8)).toShort().toInt()

private class WavPcmSink(
    file: File,
    private val sampleRate: Int,
    private val channels: ChannelMode
) : PcmSink {
    private val output = RandomAccessFile(file, "rw")
    private var bytes = 0L
    private var finished = false

    init {
        output.setLength(0)
        WavEditor.writeHeader(output, sampleRate, channels.count, 0)
    }

    override fun write(pcm: ByteArray, count: Int) {
        check(!finished)
        check(bytes + count <= 0xffff_ffffL - 36) { "WAV reached its 4 GB format limit. Recording has been saved." }
        output.write(pcm, 0, count)
        bytes += count
    }

    override fun finish() {
        if (finished) return
        finished = true
        try {
            WavEditor.writeHeader(output, sampleRate, channels.count, bytes)
            output.fd.sync()
        } finally {
            output.close()
        }
    }
}

private class CodecPcmSink(
    file: File,
    settings: RecorderSettings,
    private val mime: String
) : PcmSink {
    private val frameBytes = settings.channels.count * 2
    private val sampleRate = settings.sampleRate
    private val codec: MediaCodec
    private val encodedOutput: EncodedOutput
    private val info = MediaCodec.BufferInfo()
    private var submittedFrames = 0L
    private var finished = false
    private var outputEnded = false

    init {
        val format = MediaFormat.createAudioFormat(mime, sampleRate, settings.channels.count).apply {
            setInteger(MediaFormat.KEY_PCM_ENCODING, AndroidAudioFormat.ENCODING_PCM_16BIT)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            when (mime) {
                MediaFormat.MIMETYPE_AUDIO_FLAC -> setInteger(MediaFormat.KEY_FLAC_COMPRESSION_LEVEL, 5)
                MediaFormat.MIMETYPE_AUDIO_AAC -> {
                    setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                    setInteger(MediaFormat.KEY_BIT_RATE, settings.bitrate)
                }
                MediaFormat.MIMETYPE_AUDIO_OPUS -> setInteger(MediaFormat.KEY_BIT_RATE, settings.bitrate)
            }
        }
        val codecName = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(format)
            ?: error("This device has no ${settings.format.name} encoder for the selected settings.")
        codec = MediaCodec.createByCodecName(codecName)
        encodedOutput = if (mime == MediaFormat.MIMETYPE_AUDIO_FLAC) {
            FlacEncodedOutput(file)
        } else {
            val muxerFormat = if (mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            } else {
                if (Build.VERSION.SDK_INT < 29) error("Opus/Ogg requires Android 10 or later.")
                MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG
            }
            MuxedEncodedOutput(file, muxerFormat)
        }
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()
        } catch (t: Throwable) {
            runCatching { codec.release() }
            runCatching { encodedOutput.close() }
            throw t
        }
    }

    override fun write(pcm: ByteArray, count: Int) {
        check(!finished)
        require(count % frameBytes == 0) { "PCM data is not frame aligned." }
        var offset = 0
        val deadline = System.nanoTime() + 5_000_000_000L
        while (offset < count) {
            val index = codec.dequeueInputBuffer(10_000)
            if (index >= 0) {
                val input = checkNotNull(codec.getInputBuffer(index))
                input.clear()
                val bytes = minOf(count - offset, input.remaining()) / frameBytes * frameBytes
                check(bytes > 0) { "${mime.substringAfter('/')} encoder input buffer is too small." }
                input.put(pcm, offset, bytes)
                val timeUs = submittedFrames * 1_000_000L / sampleRate
                codec.queueInputBuffer(index, 0, bytes, timeUs, 0)
                submittedFrames += bytes / frameBytes
                offset += bytes
                drain(untilEnd = false)
            } else {
                drain(untilEnd = false)
                check(System.nanoTime() < deadline) { "The audio encoder stopped accepting data." }
            }
        }
    }

    override fun finish() {
        if (finished) return
        finished = true
        var thrown: Throwable? = null
        try {
            val deadline = System.nanoTime() + 5_000_000_000L
            while (true) {
                val index = codec.dequeueInputBuffer(10_000)
                if (index >= 0) {
                    codec.queueInputBuffer(
                        index,
                        0,
                        0,
                        submittedFrames * 1_000_000L / sampleRate,
                        MediaCodec.BUFFER_FLAG_END_OF_STREAM
                    )
                    break
                }
                drain(untilEnd = false)
                check(System.nanoTime() < deadline) { "The audio encoder could not be finalized." }
            }
            drain(untilEnd = true)
            encodedOutput.verify()
        } catch (t: Throwable) {
            thrown = t
        } finally {
            runCatching { codec.stop() }.onFailure { failure ->
                if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
            }
            runCatching { codec.release() }.onFailure { failure ->
                if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
            }
            runCatching { encodedOutput.close() }.onFailure { failure ->
                if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
            }
        }
        thrown?.let { throw it }
    }

    private fun drain(untilEnd: Boolean) {
        val deadline = System.nanoTime() + 5_000_000_000L
        while (!outputEnded) {
            val index = codec.dequeueOutputBuffer(info, if (untilEnd) 10_000 else 0)
            when {
                index >= 0 -> {
                    try {
                        val buffer = checkNotNull(codec.getOutputBuffer(index))
                        if (info.size > 0) encodedOutput.write(buffer, info)
                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                    } finally {
                        codec.releaseOutputBuffer(index, false)
                    }
                    if (!untilEnd && !outputEnded) continue
                }
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> encodedOutput.format(codec.outputFormat)
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!untilEnd) return
                    check(System.nanoTime() < deadline) { "The audio encoder did not finish within five seconds." }
                }
            }
            if (!untilEnd || outputEnded) return
        }
    }
}

private interface EncodedOutput {
    fun format(format: MediaFormat)
    fun write(buffer: ByteBuffer, info: MediaCodec.BufferInfo)
    fun verify()
    fun close()
}

private class FlacEncodedOutput(file: File) : EncodedOutput {
    private val fileOutput = FileOutputStream(file)
    private val flac = FlacOutput(fileOutput)

    override fun format(format: MediaFormat) {
        format.getByteBuffer("csd-0")?.duplicate()?.let { flac.write(it, true) }
    }

    override fun write(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        val view = buffer.duplicate().apply {
            position(info.offset)
            limit(info.offset + info.size)
        }
        flac.write(view, info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0)
    }

    override fun verify() { check(flac.started) { "The encoder did not produce a FLAC header." } }
    override fun close() {
        var thrown: Throwable? = null
        runCatching { fileOutput.fd.sync() }.onFailure { thrown = it }
        runCatching { fileOutput.close() }.onFailure { failure ->
            if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
        }
        thrown?.let { throw it }
    }
}

private class MuxedEncodedOutput(file: File, format: Int) : EncodedOutput {
    private val muxer = MediaMuxer(file.absolutePath, format)
    private var track = -1
    private var started = false

    override fun format(format: MediaFormat) {
        check(!started) { "The encoded audio format changed twice." }
        track = muxer.addTrack(format)
        muxer.start()
        started = true
    }

    override fun write(buffer: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) return
        check(started && track >= 0) { "The audio container did not receive an output format." }
        val view = buffer.duplicate().apply {
            position(info.offset)
            limit(info.offset + info.size)
        }.slice()
        val sampleInfo = MediaCodec.BufferInfo().apply {
            set(0, info.size, info.presentationTimeUs, info.flags)
        }
        muxer.writeSampleData(track, view, sampleInfo)
    }

    override fun verify() { check(started) { "The audio container was not started." } }

    override fun close() {
        var thrown: Throwable? = null
        if (started) runCatching { muxer.stop() }.onFailure { thrown = it }
        runCatching { muxer.release() }.onFailure { failure ->
            if (thrown == null) thrown = failure else thrown?.addSuppressed(failure)
        }
        thrown?.let { throw it }
    }
}
