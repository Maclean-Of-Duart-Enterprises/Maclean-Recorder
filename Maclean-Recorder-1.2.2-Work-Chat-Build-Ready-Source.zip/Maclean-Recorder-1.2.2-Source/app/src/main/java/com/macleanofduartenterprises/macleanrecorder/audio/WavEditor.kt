/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.file.Files
import java.nio.file.StandardCopyOption

object WavEditor {
    /** Writes a complete temporary file before atomically replacing the destination. */
    fun trim16BitPcm(input: File, output: File, startMs: Long, endMs: Long) {
        require(startMs >= 0 && endMs > startMs) { "End time must be after a non-negative start time." }
        val temp = File.createTempFile("trim-", ".tmp", output.absoluteFile.parentFile)
        try {
            RandomAccessFile(input, "r").use { src ->
                require(src.length() >= 12 && src.readTag() == "RIFF") { "Not a RIFF WAV file." }
                val riffEnd = src.readLe32() + 8
                require(src.readTag() == "WAVE" && riffEnd <= src.length()) { "Incomplete WAV file." }
                var channels = 0
                var rate = 0
                var dataOffset = -1L
                var dataSize = 0L
                while (src.filePointer + 8 <= riffEnd) {
                    val tag = src.readTag()
                    val size = src.readLe32()
                    val offset = src.filePointer
                    require(size <= riffEnd - offset) { "Truncated WAV chunk." }
                    when (tag) {
                        "fmt " -> {
                            require(size >= 16 && src.readLe16() == 1) { "Only 16-bit PCM WAV can be trimmed." }
                            channels = src.readLe16()
                            val sampleRate = src.readLe32()
                            val byteRate = src.readLe32()
                            val blockAlign = src.readLe16()
                            val bits = src.readLe16()
                            require(channels in 1..2 && sampleRate in 1..384000 && bits == 16 &&
                                blockAlign == channels * 2 && byteRate == sampleRate * blockAlign) { "Unsupported PCM format." }
                            rate = sampleRate.toInt()
                        }
                        "data" -> if (dataOffset < 0) { dataOffset = offset; dataSize = size }
                    }
                    src.seek(offset + size + size % 2)
                }
                require(rate > 0 && dataOffset >= 0) { "WAV is missing format or audio data." }
                val frameSize = channels * 2
                require(dataSize % frameSize == 0L) { "Incomplete PCM frame." }
                val frames = dataSize / frameSize
                fun frame(ms: Long): Long = if (ms >= (frames * 1000 + rate - 1) / rate) frames else ms * rate / 1000
                val start = frame(startMs)
                val end = frame(endMs)
                require(end > start) { "The selected region is outside the recording or is empty." }
                val length = (end - start) * frameSize
                RandomAccessFile(temp, "rw").use { out ->
                    writeHeader(out, rate, channels, length)
                    src.seek(dataOffset + start * frameSize)
                    val buffer = ByteArray(65536)
                    var remaining = length
                    while (remaining > 0) {
                        val count = minOf(buffer.size.toLong(), remaining).toInt()
                        src.readFully(buffer, 0, count)
                        out.write(buffer, 0, count)
                        remaining -= count
                    }
                    out.fd.sync()
                }
            }
            Files.move(temp.toPath(), output.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
        } finally { temp.delete() }
    }

    internal fun writeHeader(out: RandomAccessFile, rate: Int, channels: Int, bytes: Long) {
        require(bytes in 0..0xffff_ffffL - 36) { "Recording exceeds the PCM WAV size limit." }
        out.seek(0)
        out.writeBytes("RIFF"); out.writeLe32(bytes + 36); out.writeBytes("WAVEfmt ")
        out.writeLe32(16); out.writeLe16(1); out.writeLe16(channels)
        out.writeLe32(rate.toLong()); out.writeLe32(rate.toLong() * channels * 2)
        out.writeLe16(channels * 2); out.writeLe16(16); out.writeBytes("data"); out.writeLe32(bytes)
    }

    private fun RandomAccessFile.readTag(): String = ByteArray(4).also { readFully(it) }.toString(Charsets.US_ASCII)
    private fun RandomAccessFile.readLe16(): Int = readUnsignedByte() or (readUnsignedByte() shl 8)
    private fun RandomAccessFile.readLe32(): Long = readLe16().toLong() or (readLe16().toLong() shl 16)
    private fun RandomAccessFile.writeLe16(value: Int) { write(value); write(value ushr 8) }
    private fun RandomAccessFile.writeLe32(value: Long) { writeLe16(value.toInt()); writeLe16((value ushr 16).toInt()) }
}
