/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio
import android.media.MediaRecorder
import com.macleanofduartenterprises.macleanrecorder.data.InputChoice
object AudioInputManager { fun source(choice:InputChoice)=when(choice){InputChoice.BUILT_IN_MIC->MediaRecorder.AudioSource.MIC;InputChoice.BLUETOOTH->MediaRecorder.AudioSource.VOICE_RECOGNITION;InputChoice.SYSTEM_DEFAULT->MediaRecorder.AudioSource.DEFAULT} }
