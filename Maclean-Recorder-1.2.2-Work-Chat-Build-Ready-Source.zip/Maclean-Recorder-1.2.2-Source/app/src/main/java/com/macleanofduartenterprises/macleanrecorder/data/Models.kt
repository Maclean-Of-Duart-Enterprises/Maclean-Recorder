/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.data

import java.util.Locale

object AppearanceColors {
    const val BACKGROUND = "#F3F6F2"
    const val BUTTON = "#6750A4"
    const val LINE = "#79747E"
    const val LETTER = "#1D1B20"

    private val sixDigitHex = Regex("^#[0-9A-Fa-f]{6}$")

    fun normalize(value: String?, fallback: String): String =
        value?.takeIf(sixDigitHex::matches)?.uppercase(Locale.US) ?: fallback
}

enum class AudioFormat(val extension: String) { MP3("mp3"), WAV("wav"), FLAC("flac"), M4A("m4a"), OPUS("ogg") }
enum class ChannelMode(val count:Int) { MONO(1), STEREO(2) }
enum class InputChoice { SYSTEM_DEFAULT, BUILT_IN_MIC, BLUETOOTH }
enum class RecordingSource(val label: String, val usesDeviceAudio: Boolean, val usesMicrophone: Boolean) {
    DEVICE("Device audio", true, false),
    MICROPHONE("Microphone", false, true),
    DEVICE_AND_MICROPHONE("Device + microphone", true, true)
}

data class RecorderSettings(
    val format: AudioFormat = AudioFormat.MP3,
    val channels: ChannelMode = ChannelMode.MONO,
    val sampleRate: Int = 48000,
    val bitrate: Int = 192000,
    val recordingSource: RecordingSource = RecordingSource.MICROPHONE,
    val input: InputChoice = InputChoice.SYSTEM_DEFAULT,
    val backgroundUri: String = "",
    val backgroundColorHex: String = AppearanceColors.BACKGROUND,
    val buttonColorHex: String = AppearanceColors.BUTTON,
    val lineColorHex: String = AppearanceColors.LINE,
    val letterColorHex: String = AppearanceColors.LETTER,
    val backgroundOpacity: Float = .12f,
    val textScale: Float = 1f,
    val highContrast: Boolean = false,
    val keepScreenOn: Boolean = false,
    val noiseSuppression: Boolean = false,
    val equalizerEnabled: Boolean = false
)

data class RecordingItem(
    val id: String,
    val title: String,
    val path: String,
    val createdAt: Long,
    val durationMs: Long = 0,
    val format: AudioFormat = AudioFormat.WAV,
    val favorite: Boolean = false,
    val folder: String = "Recordings",
    val tags: Set<String> = emptySet()
)
