/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.media.audiofx.Equalizer
import android.media.audiofx.NoiseSuppressor

class AudioEffects(sessionId: Int, noiseSuppression: Boolean, equalizer: Boolean) : AutoCloseable {
    private val ns: NoiseSuppressor? = if (noiseSuppression && NoiseSuppressor.isAvailable()) {
        var effect: NoiseSuppressor? = null
        try { effect = NoiseSuppressor.create(sessionId); effect?.enabled = true; effect }
        catch (_: Exception) { runCatching { effect?.release() }; null }
    } else null
    private val eq: Equalizer? = if (equalizer) {
        var effect: Equalizer? = null
        try {
            effect = Equalizer(0, sessionId)
            val level = (effect.bandLevelRange[1] / 5).toShort()
            for (band in 0 until effect.numberOfBands.toInt()) effect.setBandLevel(band.toShort(), level)
            effect.enabled = true
            effect
        } catch (_: Exception) { runCatching { effect?.release() }; null }
    } else null
    override fun close() { runCatching { ns?.release() }; runCatching { eq?.release() } }
}
