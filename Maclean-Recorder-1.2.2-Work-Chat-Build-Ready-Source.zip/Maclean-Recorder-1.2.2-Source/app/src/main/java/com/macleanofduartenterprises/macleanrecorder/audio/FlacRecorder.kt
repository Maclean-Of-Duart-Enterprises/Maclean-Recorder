/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.annotation.SuppressLint
import android.media.*
import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.concurrent.thread

/** Uses the Android FLAC encoder; no bundled codec or native runtime. */
class FlacRecorder {
    @Volatile private var running = false
    @Volatile private var failure: Throwable? = null
    private var worker: Thread? = null
    private var audioRecord: AudioRecord? = null

    @SuppressLint("MissingPermission") // Permission is checked by RecordingService.
    fun start(file: File, rate: Int, channels: ChannelMode, source: Int,
              noiseSuppression: Boolean = false, equalizer: Boolean = false,
              device: AudioDeviceInfo? = null, onError: (Throwable) -> Unit, onAmplitude: (Float) -> Unit) {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_FLAC, rate, channels.count).apply {
            setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            setInteger(MediaFormat.KEY_FLAC_COMPRESSION_LEVEL, 5)
        }
        val codecName = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(format)
            ?: error("This device has no FLAC encoder for the selected sample rate and channels.")
        val codec = MediaCodec.createByCodecName(codecName)
        var effects: AudioEffects? = null
        var output: FileOutputStream? = null
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start()
            val mask = if (channels == ChannelMode.MONO) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
            val minimum = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT)
            require(minimum > 0) { "The microphone does not support the selected FLAC recording settings." }
            val bufferSize = maxOf(minimum, 8192)
            val record = AudioRecord.Builder().setAudioSource(source).setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(mask).build())
                .setBufferSizeInBytes(bufferSize * 2).build()
            audioRecord = record
            check(record.state == AudioRecord.STATE_INITIALIZED) { "Microphone initialization failed." }
            if (device != null) check(record.setPreferredDevice(device)) { "The selected input could not be routed." }
            effects = AudioEffects(record.audioSessionId, noiseSuppression, equalizer)
            val out = FileOutputStream(file); output = out
            record.startRecording()
            check(record.recordingState == AudioRecord.RECORDSTATE_RECORDING) { "Microphone recording could not start." }
            running = true; failure = null
            val activeEffects = effects
            worker = thread(name = "flac-recorder") {
                try {
                    val stream = FlacOutput(out)
                    val info = MediaCodec.BufferInfo()
                    val temp = ByteArray(bufferSize)
                    var frames = 0L
                    var inputEnded = false
                    var outputEnded = false
                    var endDeadline = Long.MAX_VALUE
                    while (!outputEnded) {
                        if (!running && endDeadline == Long.MAX_VALUE) endDeadline = System.nanoTime() + 5_000_000_000L
                        check(System.nanoTime() < endDeadline) { "The FLAC encoder did not finish within five seconds." }
                        if (!inputEnded) {
                            val index = codec.dequeueInputBuffer(10000)
                            if (index >= 0) {
                                val input = checkNotNull(codec.getInputBuffer(index)); input.clear()
                                val frameSize = channels.count * 2
                                val capacity = minOf(temp.size, input.remaining()) / frameSize * frameSize
                                check(capacity > 0) { "FLAC encoder input buffer is too small." }
                                val count = if (running) record.read(temp, 0, capacity) else 0
                                if (count < 0 && running) error("Microphone read failed ($count).")
                                if (count > 0) {
                                    input.put(temp, 0, count)
                                    codec.queueInputBuffer(index, 0, count, frames * 1_000_000L / rate, 0)
                                    frames += count / frameSize
                                    onAmplitude(pcmPeak(temp, count))
                                } else if (!running) {
                                    codec.queueInputBuffer(index, 0, 0, frames * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                    inputEnded = true
                                } else codec.queueInputBuffer(index, 0, 0, frames * 1_000_000L / rate, 0)
                            }
                        }
                        var draining = true
                        while (draining) {
                            val index = codec.dequeueOutputBuffer(info, if (inputEnded) 10000 else 0)
                            when {
                                index >= 0 -> {
                                    try {
                                        if (info.size > 0) {
                                            val buffer = checkNotNull(codec.getOutputBuffer(index)).duplicate()
                                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                                            stream.write(buffer, info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0)
                                        }
                                        outputEnded = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0
                                    } finally { codec.releaseOutputBuffer(index, false) }
                                    if (outputEnded) draining = false
                                }
                                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED ->
                                    codec.outputFormat.getByteBuffer("csd-0")?.let { stream.write(it.duplicate(), true) }
                                else -> draining = false
                            }
                        }
                    }
                    check(stream.started) { "The encoder did not produce a FLAC header." }
                    out.fd.sync()
                } catch (t: Exception) { failure = t }
                finally {
                    running = false
                    runCatching { out.close() }; activeEffects?.close()
                    runCatching { codec.stop() }; runCatching { codec.release() }
                    failure?.let(onError)
                }
            }
        } catch (t: Exception) {
            running = false
            runCatching { audioRecord?.release() }; audioRecord = null
            effects?.close(); runCatching { output?.close() }
            runCatching { codec.stop() }; runCatching { codec.release() }
            throw t
        }
    }
    fun stop() {
        running = false
        val record = audioRecord
        try { runCatching { record?.stop() }; worker?.join(); failure?.let { throw it } }
        finally { record?.release(); audioRecord = null; worker = null }
    }
}

internal class FlacOutput(private val output: FileOutputStream) {
    var started = false
        private set
    fun write(buffer: ByteBuffer, config: Boolean) {
        if (config && started) return // Some encoders report the same header in csd-0 and a config buffer.
        val bytes = ByteArray(buffer.remaining()); buffer.get(bytes)
        if (bytes.isEmpty()) return
        if (!started) {
            val marker = bytes.size >= 4 && bytes.copyOfRange(0, 4).contentEquals(byteArrayOf(102, 76, 97, 67))
            if (!marker) {
                check(config && bytes.size == 34) { "The platform encoder returned an unsupported FLAC header." }
                output.write(byteArrayOf(102, 76, 97, 67, -128, 0, 0, 34))
            }
            started = true
        }
        output.write(bytes)
    }
}
