/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.data

import android.content.Context
import com.macleanofduartenterprises.macleanrecorder.audio.WavEditor
import android.media.MediaMetadataRetriever
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

class RecordingRepository private constructor(context: Context) {
    private val dir = File(context.filesDir, "recordings").apply { mkdirs() }
    private val prefs = context.getSharedPreferences("recording_metadata", Context.MODE_PRIVATE)
    private val _items = MutableStateFlow<List<RecordingItem>>(emptyList())
    val items: StateFlow<List<RecordingItem>> = _items
    @Volatile var activePath: String? = null
    private val durations = mutableMapOf<String, Triple<Long, Long, Long>>()

    fun directory() = dir
    @Synchronized fun refresh() { _items.value = scan() }
    @Synchronized fun delete(ids: Set<String>) {
        val failures = mutableListOf<String>()
        _items.value.filter { it.id in ids }.forEach { item ->
            val file = File(item.path)
            if (item.path == activePath || (file.exists() && !file.delete())) failures += item.title
            else { prefs.edit().remove(item.id).remove("path:${item.path}").apply(); durations.remove(item.path) }
        }
        refresh()
        check(failures.isEmpty()) { "Could not delete: ${failures.joinToString()}" }
    }
    fun favorite(id: String) = update(id) { it.put("favorite", !it.optBoolean("favorite", false)) }
    fun rename(id: String, title: String) = update(id) { it.put("title", title.trim().ifBlank { "Recording" }) }
    fun setFolder(id: String, folder: String) = update(id) { it.put("folder", folder.trim().ifBlank { "Recordings" }) }
    fun setTags(id: String, tags: Set<String>) = update(id) { it.put("tags", JSONArray(tags.sorted())) }
    fun editMetadata(id: String, title: String, folder: String, tags: Set<String>) = update(id) {
        it.put("title", title.trim().ifBlank { "Recording" }).put("folder", folder.trim().ifBlank { "Recordings" }).put("tags", JSONArray(tags.sorted()))
    }
    @Synchronized fun trimWav(id: String, startMs: Long, endMs: Long, replace: Boolean) {
        val item = items.value.firstOrNull { it.id == id } ?: error("The recording no longer exists.")
        require(item.format == AudioFormat.WAV) { "Trimming supports 16-bit PCM WAV recordings." }
        val source = File(item.path)
        check(source.absolutePath != activePath) { "Stop recording before trimming this file." }
        val output = if (replace) source else File(source.parentFile, source.nameWithoutExtension + "_trimmed_" + UUID.randomUUID().toString().take(8) + ".wav")
        WavEditor.trim16BitPcm(source, output, startMs, endMs)
        durations.remove(output.absolutePath)
        if (!replace) {
            val copy = metadata(id).put("title", item.title + " (trimmed)")
            prefs.edit().putString(ensureId(output), copy.toString()).apply()
        }
        refresh()
    }
    @Synchronized private fun update(id: String, change: (JSONObject) -> Unit) {
        if (_items.value.none { it.id == id }) return
        val obj = metadata(id); change(obj); prefs.edit().putString(id, obj.toString()).apply(); refresh()
    }
    private fun metadata(id: String): JSONObject = runCatching { JSONObject(prefs.getString(id, null) ?: "{}") }.getOrDefault(JSONObject())
    private fun ensureId(file: File): String {
        val key = "path:${file.absolutePath}"
        return prefs.getString(key, null) ?: UUID.randomUUID().toString().also { prefs.edit().putString(key, it).apply() }
    }
    private fun duration(file: File): Long {
        val cached = durations[file.absolutePath]
        if (cached != null && cached.first == file.lastModified() && cached.second == file.length()) return cached.third
        val value = runCatching {
            val retriever = MediaMetadataRetriever()
            try { retriever.setDataSource(file.absolutePath); retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L }
            finally { retriever.release() }
        }.getOrDefault(0L)
        durations[file.absolutePath] = Triple(file.lastModified(), file.length(), value)
        return value
    }
    private fun scan(): List<RecordingItem> = dir.listFiles()?.filter {
        it.isFile && it.absolutePath != activePath && it.extension.lowercase() in setOf("mp3", "wav", "flac", "m4a", "ogg", "opus")
    }?.sortedByDescending { it.lastModified() }?.map { file ->
        val format = when (file.extension.lowercase()) { "mp3" -> AudioFormat.MP3; "flac" -> AudioFormat.FLAC; "m4a" -> AudioFormat.M4A; "ogg", "opus" -> AudioFormat.OPUS; else -> AudioFormat.WAV }
        val id = ensureId(file); val m = metadata(id)
        val tags = m.optJSONArray("tags")?.let { a -> (0 until a.length()).mapNotNull { a.optString(it).takeIf(String::isNotBlank) }.toSet() } ?: emptySet()
        RecordingItem(id, m.optString("title", file.nameWithoutExtension), file.absolutePath, file.lastModified(), duration(file),
            format, m.optBoolean("favorite", false), m.optString("folder", "Recordings"), tags)
    } ?: emptyList()

    companion object {
        @Volatile private var instance: RecordingRepository? = null
        fun get(context: Context): RecordingRepository = instance ?: synchronized(this) {
            instance ?: RecordingRepository(context.applicationContext).also { instance = it }
        }
    }
}
