/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import android.annotation.SuppressLint
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

class WavRecorder {
    private var audioRecord: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var failure: Throwable? = null
    private var worker: Thread? = null

    @SuppressLint("MissingPermission") // RecordingService checks RECORD_AUDIO before starting capture.
    fun start(file: File, sampleRate: Int, channels: ChannelMode, source: Int,
              noiseSuppression: Boolean = false, equalizer: Boolean = false,
              device: AudioDeviceInfo? = null, onError: (Throwable) -> Unit,
              onAmplitude: (Float) -> Unit) {
        val mask = if (channels == ChannelMode.MONO) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
        val minimum = AudioRecord.getMinBufferSize(sampleRate, mask, AudioFormat.ENCODING_PCM_16BIT)
        require(minimum > 0) { "This microphone does not support the selected sample rate and channel count." }
        val size = maxOf(minimum, 8192) * 2
        val ar = AudioRecord.Builder().setAudioSource(source).setAudioFormat(AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(mask).build())
            .setBufferSizeInBytes(size).build()
        audioRecord = ar
        var effects: AudioEffects? = null
        var output: RandomAccessFile? = null
        try {
            check(ar.state == AudioRecord.STATE_INITIALIZED) { "Microphone initialization failed." }
            if (device != null) check(ar.setPreferredDevice(device)) { "The selected input could not be routed." }
            effects = AudioEffects(ar.audioSessionId, noiseSuppression, equalizer)
            val out = RandomAccessFile(file, "rw"); output = out
            out.setLength(0); WavEditor.writeHeader(out, sampleRate, channels.count, 0)
            ar.startRecording()
            check(ar.recordingState == AudioRecord.RECORDSTATE_RECORDING) { "Microphone recording could not start." }
            running = true; failure = null
            val activeEffects = effects
            worker = thread(name = "wav-recorder") {
                var bytes = 0L
                try {
                    val buffer = ByteArray(size)
                    while (running) {
                        val count = ar.read(buffer, 0, buffer.size)
                        if (count < 0) { if (running) error("Microphone read failed ($count)."); break }
                        if (count == 0) continue
                        check(bytes + count <= 0xffff_ffffL - 36) { "WAV reached its 4 GB format limit. Recording has been saved." }
                        out.write(buffer, 0, count); bytes += count
                        onAmplitude(pcmPeak(buffer, count))
                    }
                } catch (t: Exception) { failure = t }
                finally {
                    running = false
                    runCatching { WavEditor.writeHeader(out, sampleRate, channels.count, bytes); out.fd.sync() }
                        .onFailure { failure = it }
                    runCatching { out.close() }; activeEffects?.close()
                    failure?.let(onError)
                }
            }
        } catch (t: Exception) {
            running = false
            runCatching { output?.close() }; effects?.close()
            runCatching { ar.release() }; audioRecord = null
            throw t
        }
    }

    fun stop() {
        running = false
        val ar = audioRecord
        try {
            runCatching { ar?.stop() }
            worker?.join()
            failure?.let { throw it }
        } finally { ar?.release(); audioRecord = null; worker = null }
    }
}

internal fun pcmPeak(buffer: ByteArray, count: Int): Float {
    var peak = 0
    var i = 0
    while (i + 1 < count) {
        val sample = ((buffer[i].toInt() and 255) or (buffer[i + 1].toInt() shl 8)).toShort().toInt()
        peak = maxOf(peak, kotlin.math.abs(sample)); i += 2
    }
    return peak / 32768f
}
