/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable

@Composable
fun MacleanTheme(content: @Composable () -> Unit) {
    MaterialTheme(typography = Typography(), content = content)
}
