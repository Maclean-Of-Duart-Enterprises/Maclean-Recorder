/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.macleanofduartenterprises.macleanrecorder.data.AppearanceColors
import com.macleanofduartenterprises.macleanrecorder.data.AudioFormat
import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import com.macleanofduartenterprises.macleanrecorder.data.InputChoice
import com.macleanofduartenterprises.macleanrecorder.data.RecorderSettings
import com.macleanofduartenterprises.macleanrecorder.data.RecordingItem
import com.macleanofduartenterprises.macleanrecorder.data.RecordingSource
import com.macleanofduartenterprises.macleanrecorder.ui.theme.MacleanTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MacleanTheme { App() } }
    }
}

@Composable
private fun App(vm: RecorderViewModel = viewModel()) {
    val settings by vm.settings.collectAsState()
    val recordings by vm.recordings.collectAsState()
    val active by vm.recording.collectAsState()
    val amplitude by vm.amplitude.collectAsState()
    val error by vm.error.collectAsState()
    val busy by vm.busy.collectAsState()
    val activeSettings by vm.activeSettings.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var licenses by remember { mutableStateOf(false) }
    val activity = LocalContext.current as ComponentActivity
    val projectionManager = remember {
        activity.getSystemService(MediaProjectionManager::class.java)
    }

    DisposableEffect(settings.keepScreenOn) {
        if (settings.keepScreenOn) {
            activity.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        onDispose { }
    }

    val projectionPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) {
            vm.start(result.resultCode, data)
        } else {
            vm.showError("Device audio capture was not approved.")
        }
    }
    val startAfterPermissions: () -> Unit = {
        if (settings.recordingSource.usesDeviceAudio) {
            if (Build.VERSION.SDK_INT < 29) {
                vm.showError("Device audio capture requires Android 10 or later.")
            } else {
                projectionPermission.launch(projectionManager.createScreenCaptureIntent())
            }
        } else {
            vm.start()
        }
    }
    val permissions = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        when {
            result[Manifest.permission.RECORD_AUDIO] != true ->
                vm.showError("Allow microphone and audio-recording permission first.")
            Build.VERSION.SDK_INT >= 31 &&
                settings.recordingSource.usesMicrophone &&
                settings.input == InputChoice.BLUETOOTH &&
                result[Manifest.permission.BLUETOOTH_CONNECT] != true ->
                vm.showError("Allow Nearby devices permission to use a Bluetooth microphone.")
            else -> startAfterPermissions()
        }
    }
    fun requestRecording() {
        val requested = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (
            Build.VERSION.SDK_INT >= 31 &&
            settings.recordingSource.usesMicrophone &&
            settings.input == InputChoice.BLUETOOTH
        ) {
            requested += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT >= 33) requested += Manifest.permission.POST_NOTIFICATIONS
        permissions.launch(requested.toTypedArray())
    }

    CompositionLocalProviderWithScale(settings.textScale) {
        val scheme = recorderColorScheme(settings)
        val background = scheme.background
        MaterialTheme(colorScheme = scheme) {
            Box(Modifier.fillMaxSize().background(background)) {
                if (!settings.highContrast) BackgroundImage(settings)
                Scaffold(
                    containerColor = Color.Transparent,
                    contentColor = scheme.onBackground,
                    bottomBar = {
                        NavigationBar(containerColor = background, contentColor = scheme.onBackground) {
                            listOf(
                                "Record" to Icons.Default.Mic,
                                "Library" to Icons.Default.LibraryMusic,
                                "Settings" to Icons.Default.Settings
                            ).forEachIndexed { index, destination ->
                                NavigationBarItem(
                                    selected = tab == index,
                                    onClick = { tab = index },
                                    icon = { Icon(destination.second, null) },
                                    label = { Text(destination.first) }
                                )
                            }
                        }
                    }
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (tab) {
                            0 -> RecordScreen(
                                active,
                                amplitude,
                                { if (active) vm.stop() else requestRecording() },
                                activeSettings ?: settings,
                                busy
                            )
                            1 -> LibraryScreen(recordings, vm)
                            else -> SettingsScreen(settings, vm::save, { licenses = true })
                        }
                        if (licenses) LicenseDialog { licenses = false }
                        error?.let { message ->
                            AlertDialog(
                                onDismissRequest = vm::clearError,
                                confirmButton = {
                                    TextButton(onClick = vm::clearError) { Text("OK") }
                                },
                                title = { Text("Recorder") },
                                text = { Text(message) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompositionLocalProviderWithScale(scale: Float, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    androidx.compose.runtime.CompositionLocalProvider(
        LocalDensity provides Density(density.density, density.fontScale * scale.coerceIn(0.8f, 1.8f)),
        content = content
    )
}

@Composable
private fun BackgroundImage(settings: RecorderSettings) {
    if (settings.backgroundUri.isBlank()) return
    val context = LocalContext.current
    var bitmap by remember(settings.backgroundUri) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(settings.backgroundUri) {
        bitmap = withContext(Dispatchers.IO) {
            runCatching {
                val uri = Uri.parse(settings.backgroundUri)
                if (Build.VERSION.SDK_INT >= 28) {
                    ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri)) {
                            decoder, info, _ ->
                        val ratio = maxOf(info.size.width, info.size.height) / 2048f
                        if (ratio > 1f) {
                            decoder.setTargetSize(
                                maxOf(1, (info.size.width / ratio).toInt()),
                                maxOf(1, (info.size.height / ratio).toInt())
                            )
                        }
                    }
                } else {
                    val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, options)
                    }
                    options.inSampleSize = 1
                    while (maxOf(options.outWidth, options.outHeight) / options.inSampleSize > 2048) {
                        options.inSampleSize *= 2
                    }
                    options.inJustDecodeBounds = false
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it, null, options)
                    }
                }
            }.getOrNull()
        }
    }
    bitmap?.let {
        Image(
            it.asImageBitmap(),
            null,
            Modifier.fillMaxSize().alpha(settings.backgroundOpacity),
            contentScale = ContentScale.Crop
        )
    }
}

@Composable
private fun RecordScreen(
    active: Boolean,
    amplitude: Float,
    toggle: () -> Unit,
    settings: RecorderSettings,
    busy: Boolean
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Maclean Recorder", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Private, local-first audio recording")
        Spacer(Modifier.height(50.dp))
        Box(
            Modifier.fillMaxWidth().height(110.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.88f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            LinearProgressIndicator(
                progress = { amplitude.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth(0.8f),
                color = MaterialTheme.colorScheme.outline,
                trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
            )
            Text(
                if (busy) "Please wait…" else if (active) "Recording…" else "Ready",
                Modifier.padding(top = 48.dp)
            )
        }
        Spacer(Modifier.height(28.dp))
        FilledIconButton(onClick = toggle, modifier = Modifier.size(84.dp), enabled = !busy) {
            Icon(
                if (active) Icons.Default.Stop else Icons.Default.Mic,
                if (active) "Stop and save" else "Start recording",
                Modifier.size(42.dp)
            )
        }
        Spacer(Modifier.height(20.dp))
        Text("${settings.format} • ${settings.channels.name.lowercase()} • ${settings.sampleRate / 1000.0} kHz")
        Text(settings.recordingSource.label, style = MaterialTheme.typography.bodySmall)
        if (settings.noiseSuppression || settings.equalizerEnabled) {
            Text(
                listOfNotNull(
                    "Noise suppression".takeIf { settings.noiseSuppression },
                    "EQ".takeIf { settings.equalizerEnabled }
                ).joinToString(" • "),
                style = MaterialTheme.typography.bodySmall
            )
        }
        Spacer(Modifier.height(32.dp))
        WebsiteFooter()
    }
}

@Composable
private fun LibraryScreen(items: List<RecordingItem>, vm: RecorderViewModel) {
    var selected by remember { mutableStateOf(setOf<String>()) }
    var edit by remember { mutableStateOf<RecordingItem?>(null) }
    var trim by remember { mutableStateOf<RecordingItem?>(null) }
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Recordings", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            if (selected.isNotEmpty()) {
                IconButton(onClick = {
                    shareRecordings(context, items.filter { it.id in selected }, vm::showError)
                }) { Icon(Icons.Default.Share, "Share") }
                IconButton(onClick = {
                    vm.delete(selected)
                    selected = emptySet()
                }) { Icon(Icons.Default.Delete, "Delete") }
            }
        }
        if (items.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No recordings yet")
            }
        } else {
            LazyColumn(Modifier.weight(1f)) {
                items(items, key = { it.id }) { recording ->
                    ListItem(
                        headlineContent = {
                            Row {
                                Text(recording.title, Modifier.weight(1f))
                                if (recording.favorite) Icon(Icons.Default.Star, "Favorite")
                            }
                        },
                        supportingContent = {
                            Text(
                                "${recording.format} • ${recording.folder} • ${formatDuration(recording.durationMs)}" +
                                    if (recording.tags.isNotEmpty()) " • ${recording.tags.joinToString(", ")}" else ""
                            )
                        },
                        leadingContent = {
                            Checkbox(
                                checked = recording.id in selected,
                                onCheckedChange = { checked ->
                                    selected = if (checked) selected + recording.id else selected - recording.id
                                }
                            )
                        },
                        trailingContent = {
                            Row {
                                IconButton(onClick = { vm.favorite(recording.id) }) {
                                    Icon(
                                        if (recording.favorite) Icons.Default.Star else Icons.Default.StarBorder,
                                        "Favorite"
                                    )
                                }
                                Box {
                                    var open by remember { mutableStateOf(false) }
                                    IconButton(onClick = { open = true }) { Icon(Icons.Default.MoreVert, "More") }
                                    DropdownMenu(open, { open = false }) {
                                        DropdownMenuItem({ Text("Edit metadata") }, { edit = recording; open = false })
                                        DropdownMenuItem(
                                            { Text("Trim WAV") },
                                            { trim = recording; open = false },
                                            enabled = recording.format == AudioFormat.WAV
                                        )
                                        DropdownMenuItem(
                                            { Text("Share / export") },
                                            {
                                                shareRecordings(context, listOf(recording), vm::showError)
                                                open = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            { Text("Delete") },
                                            { vm.delete(setOf(recording.id)); open = false }
                                        )
                                    }
                                }
                            }
                        }
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
            }
        }
        WebsiteFooter()
    }
    edit?.let { recording ->
        MetadataDialog(
            recording,
            { edit = null }
        ) { title, folder, tags ->
            vm.editMetadata(recording.id, title, folder, tags)
            edit = null
        }
    }
    trim?.let { recording ->
        TrimDialog(recording, { trim = null }) { start, end, replace ->
            vm.trimWav(recording.id, start, end, replace)
            trim = null
        }
    }
}

@Composable
private fun MetadataDialog(
    recording: RecordingItem,
    close: () -> Unit,
    save: (String, String, Set<String>) -> Unit
) {
    var title by remember { mutableStateOf(recording.title) }
    var folder by remember { mutableStateOf(recording.folder) }
    var tags by remember { mutableStateOf(recording.tags.joinToString(", ")) }
    AlertDialog(
        onDismissRequest = close,
        confirmButton = {
            TextButton(onClick = {
                save(title, folder, tags.split(',').map(String::trim).filter(String::isNotBlank).toSet())
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Cancel") } },
        title = { Text("Recording details") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") })
                OutlinedTextField(folder, { folder = it }, label = { Text("Folder") })
                OutlinedTextField(tags, { tags = it }, label = { Text("Tags (comma separated)") })
            }
        }
    )
}

@Composable
private fun TrimDialog(
    recording: RecordingItem,
    close: () -> Unit,
    trim: (Long, Long, Boolean) -> Unit
) {
    var start by remember { mutableStateOf("0") }
    var end by remember { mutableStateOf((recording.durationMs / 1000.0).toString()) }
    var replace by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = close,
        confirmButton = {
            TextButton(onClick = {
                val first = ((start.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                val last = ((end.toDoubleOrNull() ?: 0.0) * 1000).toLong()
                trim(first, last, replace)
            }) { Text("Trim") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Cancel") } },
        title = { Text("Trim WAV") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Choose start/end in seconds. By default a new trimmed copy is created.")
                OutlinedTextField(start, { start = it }, label = { Text("Start seconds") })
                OutlinedTextField(end, { end = it }, label = { Text("End seconds") })
                SwitchRow("Replace original", replace) { replace = it }
            }
        }
    )
}

@Composable
private fun SettingsScreen(
    settings: RecorderSettings,
    save: (RecorderSettings) -> Unit,
    licenses: () -> Unit
) {
    val context = LocalContext.current
    var colorTarget by remember { mutableStateOf<AppearanceColorTarget?>(null) }
    val backgroundPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            runCatching {
                context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            save(settings.copy(backgroundUri = it.toString()))
        }
    }
    val compressedFormat = settings.format in setOf(AudioFormat.MP3, AudioFormat.M4A, AudioFormat.OPUS)
    val sampleRates = listOf(8000, 16000, 22050, 44100, 48000, 96000)
        .filter { !compressedFormat || it <= 48000 }
    val bitrates = listOf(64000, 96000, 128000, 160000, 192000, 256000, 320000)
        .filter { settings.format != AudioFormat.MP3 || it <= maxMp3Bitrate(settings.sampleRate) }
    val sources = RecordingSource.entries.filter {
        it == RecordingSource.MICROPHONE || Build.VERSION.SDK_INT >= 29
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item { Text("Settings", style = MaterialTheme.typography.headlineSmall) }
        item { Section("Recording") }
        item {
            EnumChooser(
                label = "Format",
                value = settings.format,
                values = AudioFormat.entries.filter { it != AudioFormat.OPUS || Build.VERSION.SDK_INT >= 29 },
                set = { format ->
                    val rate = settings.sampleRate.coerceAtMost(
                        if (format in setOf(AudioFormat.MP3, AudioFormat.M4A, AudioFormat.OPUS)) 48000 else 96000
                    )
                    save(
                        settings.copy(
                            format = format,
                            sampleRate = rate,
                            bitrate = if (format == AudioFormat.MP3) {
                                settings.bitrate.coerceAtMost(maxMp3Bitrate(rate))
                            } else settings.bitrate
                        )
                    )
                }
            )
        }
        item {
            EnumChooser(
                label = "Channels",
                value = settings.channels,
                values = ChannelMode.entries,
                set = { save(settings.copy(channels = it)) }
            )
        }
        item {
            NumberChooser("Sample rate", settings.sampleRate, sampleRates) {
                save(
                    settings.copy(
                        sampleRate = it,
                        bitrate = if (settings.format == AudioFormat.MP3) {
                            settings.bitrate.coerceAtMost(maxMp3Bitrate(it))
                        } else settings.bitrate
                    )
                )
            }
        }
        item {
            NumberChooser(
                "Bitrate",
                settings.bitrate,
                bitrates
            ) { save(settings.copy(bitrate = it)) }
        }
        item {
            EnumChooser(
                label = "Recording source",
                value = settings.recordingSource,
                values = sources,
                set = { save(settings.copy(recordingSource = it)) },
                display = { it.label }
            )
        }
        if (settings.recordingSource.usesMicrophone) {
            item {
                EnumChooser(
                    label = "Microphone input",
                    value = settings.input,
                    values = InputChoice.entries,
                    set = { save(settings.copy(input = it)) }
                )
            }
            item {
                SwitchRow("Noise suppression", settings.noiseSuppression) {
                    save(settings.copy(noiseSuppression = it))
                }
            }
            item {
                SwitchRow("Equalizer", settings.equalizerEnabled) {
                    save(settings.copy(equalizerEnabled = it))
                }
            }
        }
        item {
            Text(
                if (Build.VERSION.SDK_INT >= 29) {
                    "Device audio uses Android's consent prompt and records audio that other apps permit to be captured. " +
                        "Device + microphone mixes both sources evenly. Noise suppression and EQ apply to the microphone."
                } else {
                    "Device audio capture requires Android 10 or later. Noise suppression and EQ apply when the microphone supports them."
                },
                style = MaterialTheme.typography.bodySmall
            )
        }
        item { Section("Appearance") }
        item {
            Button(
                onClick = { backgroundPicker.launch(arrayOf("image/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Choose background photo") }
        }
        if (settings.backgroundUri.isNotBlank()) {
            item {
                OutlinedButton(
                    onClick = { save(settings.copy(backgroundUri = "")) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) { Text("Remove background photo") }
            }
        }
        item {
            Text("Background opacity: ${(settings.backgroundOpacity * 100).toInt()}%")
            Slider(
                settings.backgroundOpacity,
                { save(settings.copy(backgroundOpacity = it)) },
                valueRange = 0f..1f
            )
        }
        item {
            Text("Text scale: ${"%.1f".format(Locale.US, settings.textScale)}×")
            Slider(
                settings.textScale,
                { save(settings.copy(textScale = it)) },
                valueRange = 0.8f..1.8f
            )
        }
        item {
            ColorSettingButton("Background color", settings.backgroundColorHex) {
                colorTarget = AppearanceColorTarget.BACKGROUND
            }
        }
        item {
            ColorSettingButton("Button color", settings.buttonColorHex) {
                colorTarget = AppearanceColorTarget.BUTTON
            }
        }
        item {
            ColorSettingButton("Line color", settings.lineColorHex) {
                colorTarget = AppearanceColorTarget.LINE
            }
        }
        item {
            ColorSettingButton("Letter color", settings.letterColorHex) {
                colorTarget = AppearanceColorTarget.LETTER
            }
        }
        item {
            Text(
                "Choose contrasting colors for readable controls. High contrast temporarily overrides custom interface colors.",
                style = MaterialTheme.typography.bodySmall
            )
        }
        item {
            OutlinedButton(
                onClick = {
                    save(
                        settings.copy(
                            backgroundColorHex = AppearanceColors.BACKGROUND,
                            buttonColorHex = AppearanceColors.BUTTON,
                            lineColorHex = AppearanceColors.LINE,
                            letterColorHex = AppearanceColors.LETTER
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) { Text("Reset interface colors") }
        }
        item {
            SwitchRow("High contrast", settings.highContrast) {
                save(settings.copy(highContrast = it))
            }
        }
        item {
            SwitchRow("Keep screen on", settings.keepScreenOn) {
                save(settings.copy(keepScreenOn = it))
            }
        }
        item { Section("Library & export") }
        item {
            Text("Folders, tags, favorites, metadata editing, bulk delete, FileProvider sharing/export, and WAV trimming are available from Library.")
        }
        item { Section("Legal") }
        item {
            Button(onClick = licenses, modifier = Modifier.fillMaxWidth()) { Text("Licenses") }
        }
        item { Text("Application license: GNU AGPLv3 (AGPL-3.0-only)") }
        item { WebsiteFooter() }
    }

    colorTarget?.let { target ->
        val initialHex = when (target) {
            AppearanceColorTarget.BACKGROUND -> settings.backgroundColorHex
            AppearanceColorTarget.BUTTON -> settings.buttonColorHex
            AppearanceColorTarget.LINE -> settings.lineColorHex
            AppearanceColorTarget.LETTER -> settings.letterColorHex
        }
        ColorWheelDialog(
            title = target.label,
            initialHex = initialHex,
            dismiss = { colorTarget = null }
        ) { hex ->
            save(
                when (target) {
                    AppearanceColorTarget.BACKGROUND -> settings.copy(backgroundColorHex = hex)
                    AppearanceColorTarget.BUTTON -> settings.copy(buttonColorHex = hex)
                    AppearanceColorTarget.LINE -> settings.copy(lineColorHex = hex)
                    AppearanceColorTarget.LETTER -> settings.copy(letterColorHex = hex)
                }
            )
            colorTarget = null
        }
    }
}

@Composable
private fun ColorSettingButton(label: String, hex: String, onClick: () -> Unit) {
    Text(label)
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Surface(
            color = parseColor(hex),
            shape = CircleShape,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier.size(28.dp)
        ) { }
        Spacer(Modifier.size(10.dp))
        Text("Color wheel • ${hex.uppercase(Locale.US)}")
    }
}

private enum class AppearanceColorTarget(val label: String) {
    BACKGROUND("Background color"),
    BUTTON("Button color"),
    LINE("Line color"),
    LETTER("Letter color")
}

@Composable
private fun ColorWheelDialog(title: String, initialHex: String, dismiss: () -> Unit, apply: (String) -> Unit) {
    val initial = remember(initialHex) {
        FloatArray(3).also { hsv ->
            android.graphics.Color.colorToHSV(
                runCatching { android.graphics.Color.parseColor(initialHex) }
                    .getOrDefault(android.graphics.Color.rgb(243, 246, 242)),
                hsv
            )
        }
    }
    var hue by remember(initialHex) { mutableFloatStateOf(initial[0]) }
    var saturation by remember(initialHex) { mutableFloatStateOf(initial[1]) }
    var brightness by remember(initialHex) { mutableFloatStateOf(initial[2]) }
    var wheelSize by remember { mutableStateOf(IntSize.Zero) }
    val selectedHex = hsvToHex(hue, saturation, brightness)
    val wheel = remember(wheelSize, brightness) {
        if (wheelSize.width > 0) createColorWheel(min(wheelSize.width, wheelSize.height), brightness) else null
    }
    fun select(position: Offset) {
        if (wheelSize.width == 0) return
        val radius = min(wheelSize.width, wheelSize.height) / 2f
        val dx = position.x - wheelSize.width / 2f
        val dy = position.y - wheelSize.height / 2f
        saturation = (sqrt(dx * dx + dy * dy) / radius).coerceIn(0f, 1f)
        hue = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
    }

    AlertDialog(
        onDismissRequest = dismiss,
        confirmButton = { TextButton(onClick = { apply(selectedHex) }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = dismiss) { Text("Cancel") } },
        title = { Text(title) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Canvas(
                    Modifier.fillMaxWidth().aspectRatio(1f)
                        .onSizeChanged { wheelSize = it }
                        .pointerInput(wheelSize) {
                            detectTapGestures(onTap = ::select)
                        }
                        .pointerInput(wheelSize) {
                            detectDragGestures(
                                onDragStart = ::select,
                                onDrag = { change, _ ->
                                    change.consume()
                                    select(change.position)
                                }
                            )
                        }
                ) {
                    wheel?.let { drawImage(it) }
                    val radius = size.minDimension / 2f
                    val angle = hue / 180f * PI.toFloat()
                    val center = Offset(
                        size.width / 2f + cos(angle) * saturation * radius,
                        size.height / 2f + sin(angle) * saturation * radius
                    )
                    drawCircle(Color.Black, 10.dp.toPx(), center, style = Stroke(5.dp.toPx()))
                    drawCircle(Color.White, 10.dp.toPx(), center, style = Stroke(2.dp.toPx()))
                }
                Text("Brightness: ${(brightness * 100).roundToInt()}%")
                Slider(brightness, { brightness = it }, valueRange = 0f..1f)
                Surface(
                    color = parseColor(selectedHex),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            selectedHex,
                            color = if (parseColor(selectedHex).luminance() < 0.4f) Color.White else Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Text("Drag anywhere on the wheel for continuous hue and saturation choices.")
            }
        }
    )
}

private fun createColorWheel(size: Int, brightness: Float): ImageBitmap {
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(size * size)
    val radius = (size - 1) / 2f
    val center = radius
    for (y in 0 until size) {
        for (x in 0 until size) {
            val dx = x - center
            val dy = y - center
            val distance = sqrt(dx * dx + dy * dy)
            pixels[y * size + x] = if (distance <= radius) {
                val hue = ((atan2(dy, dx) * 180f / PI.toFloat()) + 360f) % 360f
                android.graphics.Color.HSVToColor(floatArrayOf(hue, distance / radius, brightness))
            } else {
                android.graphics.Color.TRANSPARENT
            }
        }
    }
    bitmap.setPixels(pixels, 0, size, 0, 0, size, size)
    return bitmap.asImageBitmap()
}

private fun hsvToHex(hue: Float, saturation: Float, brightness: Float): String {
    val color = android.graphics.Color.HSVToColor(floatArrayOf(hue, saturation, brightness))
    return String.format(Locale.US, "#%06X", color and 0x00ffffff)
}

private fun maxMp3Bitrate(sampleRate: Int): Int = when {
    sampleRate < 16_000 -> 64_000
    sampleRate < 32_000 -> 160_000
    else -> 320_000
}

@Composable
private fun Section(title: String) {
    Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
}

@Composable
private fun SwitchRow(title: String, value: Boolean, set: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(value, set)
    }
}

@Composable
private fun <T : Enum<T>> EnumChooser(
    label: String,
    value: T,
    values: List<T>,
    set: (T) -> Unit,
    display: (T) -> String = { it.name.replace('_', ' ') }
) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Text("$label: ${display(value)}")
        }
        DropdownMenu(open, { open = false }) {
            values.forEach { option ->
                DropdownMenuItem(
                    { Text(display(option)) },
                    { set(option); open = false }
                )
            }
        }
    }
}

@Composable
private fun NumberChooser(label: String, value: Int, values: List<Int>, set: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(
            onClick = { open = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) { Text("$label: $value") }
        DropdownMenu(open, { open = false }) {
            values.forEach { option ->
                DropdownMenuItem({ Text(option.toString()) }, { set(option); open = false })
            }
        }
    }
}

@Composable
private fun WebsiteFooter() {
    Text("https://macleanofduartenterprises.com/software", style = MaterialTheme.typography.bodySmall)
}

@Composable
private fun LicenseDialog(close: () -> Unit) {
    val context = LocalContext.current
    val text = remember {
        context.assets.open("licenses/AGPL-3.0.txt").bufferedReader().use { it.readText() } +
            "\n\n" + context.assets.open("licenses/THIRD-PARTY-NOTICES.txt").bufferedReader().use { it.readText() } +
            "\n\n" + context.assets.open("licenses/LGPL-3.0.txt").bufferedReader().use { it.readText() }
    }
    AlertDialog(
        onDismissRequest = close,
        confirmButton = { TextButton(close) { Text("Close") } },
        title = { Text("Licenses") },
        text = {
            Box(Modifier.heightIn(max = 520.dp).verticalScroll(rememberScrollState())) {
                SelectionContainer { Text(text) }
            }
        }
    )
}

private fun recorderColorScheme(settings: RecorderSettings): ColorScheme {
    if (settings.highContrast) {
        return darkColorScheme(
            primary = Color.Yellow,
            onPrimary = Color.Black,
            primaryContainer = Color.White,
            onPrimaryContainer = Color.Black,
            secondary = Color.Yellow,
            onSecondary = Color.Black,
            secondaryContainer = Color.White,
            onSecondaryContainer = Color.Black,
            background = Color.Black,
            onBackground = Color.White,
            surface = Color.Black,
            onSurface = Color.White,
            surfaceVariant = Color(0xff202020),
            onSurfaceVariant = Color.White,
            outline = Color.White,
            outlineVariant = Color.White
        )
    }

    val background = parseColor(settings.backgroundColorHex, Color(0xfff3f6f2))
    val button = parseColor(settings.buttonColorHex, Color(0xff6750a4))
    val line = parseColor(settings.lineColorHex, Color(0xff79747e))
    val letter = parseColor(settings.letterColorHex, Color(0xff1d1b20))
    val dark = background.luminance() < 0.35f
    val base = if (dark) darkColorScheme() else lightColorScheme()
    val accentContainer = lerp(background, button, if (dark) 0.42f else 0.24f)
    val raisedSurface = lerp(background, line, if (dark) 0.20f else 0.10f)

    return base.copy(
        primary = button,
        onPrimary = letter,
        primaryContainer = accentContainer,
        onPrimaryContainer = letter,
        inversePrimary = button,
        secondary = button,
        onSecondary = letter,
        secondaryContainer = accentContainer,
        onSecondaryContainer = letter,
        tertiary = button,
        onTertiary = letter,
        tertiaryContainer = accentContainer,
        onTertiaryContainer = letter,
        background = background,
        onBackground = letter,
        surface = background,
        onSurface = letter,
        surfaceVariant = raisedSurface,
        onSurfaceVariant = letter,
        surfaceTint = button,
        outline = line,
        outlineVariant = line
    )
}

private fun parseColor(hex: String, fallback: Color = Color(0xfff3f6f2)) = runCatching {
    Color(android.graphics.Color.parseColor(hex))
}.getOrDefault(fallback)

private fun formatDuration(milliseconds: Long): String {
    val seconds = milliseconds / 1000
    return "%d:%02d".format(Locale.US, seconds / 60, seconds % 60)
}

private fun shareRecordings(
    context: android.content.Context,
    items: List<RecordingItem>,
    onError: (String) -> Unit
) {
    if (items.isEmpty()) return
    runCatching {
        val uris = ArrayList<Uri>()
        items.forEach { item ->
            val file = File(item.path)
            check(file.isFile) { "A selected recording is no longer available." }
            uris += FileProvider.getUriForFile(context, "${context.packageName}.files", file)
        }
        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "audio/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            }
        }
        intent.clipData = android.content.ClipData.newRawUri("Recording", uris.first()).apply {
            uris.drop(1).forEach { addItem(android.content.ClipData.Item(it)) }
        }
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(intent, "Share recordings"))
    }.onFailure {
        onError(it.message ?: "No application is available to share these recordings.")
    }
}
