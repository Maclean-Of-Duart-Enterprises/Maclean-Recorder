package com.macleanofduartenterprises.macleanrecorder.audio

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.FileOutputStream
import java.nio.ByteBuffer

class AudioEncodingTest {
    @get:Rule val folder = TemporaryFolder()
    @Test fun peakHandlesSigned16BitExtremes() {
        assertEquals(1f, pcmPeak(byteArrayOf(0, -128), 2), 0f)
        assertEquals(32767f / 32768f, pcmPeak(byteArrayOf(-1, 127), 2), 0f)
        assertEquals(0f, pcmPeak(byteArrayOf(0, 0), 2), 0f)
    }
    @Test fun flacStreamInfoGetsContainerHeaderExactlyOnce() {
        val file = folder.newFile("header.flac")
        val info = ByteArray(34) { 1 }
        val frame = byteArrayOf(-1, -8, 0, 0)
        FileOutputStream(file).use {
            val writer = FlacOutput(it)
            writer.write(ByteBuffer.wrap(info), true)
            writer.write(ByteBuffer.wrap(info), true)
            writer.write(ByteBuffer.wrap(frame), false)
        }
        assertArrayEquals(byteArrayOf(102, 76, 97, 67, -128, 0, 0, 34) + info + frame, file.readBytes())
    }
    @Test fun flacFullHeaderIsPreservedAndDuplicateConfigIgnored() {
        val file = folder.newFile("full.flac")
        val header = byteArrayOf(102, 76, 97, 67, -128, 0, 0, 34) + ByteArray(34)
        FileOutputStream(file).use {
            val writer = FlacOutput(it)
            writer.write(ByteBuffer.wrap(header), true)
            writer.write(ByteBuffer.wrap(header), true)
        }
        assertArrayEquals(header, file.readBytes())
    }
    @Test fun refusesHeaderlessFlacOutput() {
        FileOutputStream(folder.newFile("broken.flac")).use {
            val writer = FlacOutput(it)
            assertThrows(IllegalStateException::class.java) { writer.write(ByteBuffer.wrap(byteArrayOf(-1, -8, 0, 0)), false) }
        }
    }
}
