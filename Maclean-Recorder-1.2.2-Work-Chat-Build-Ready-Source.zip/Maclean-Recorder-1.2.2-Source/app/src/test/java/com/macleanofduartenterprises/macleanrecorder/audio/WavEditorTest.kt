package com.macleanofduartenterprises.macleanrecorder.audio

import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.RandomAccessFile

class WavEditorTest {
    @get:Rule val folder = TemporaryFolder()
    private fun wav(name: String, channels: Int = 1): File = folder.newFile(name).also { file ->
        RandomAccessFile(file, "rw").use {
            WavEditor.writeHeader(it, 1000, channels, 1000L * channels * 2)
            repeat(1000 * channels) { sample -> it.write(sample); it.write(sample ushr 8) }
        }
    }
    @Test fun trimPreservesExactFramesAndOriginal() {
        val input = wav("in.wav", 2); val original = input.readBytes(); val output = folder.newFile("out.wav")
        WavEditor.trim16BitPcm(input, output, 100, 300)
        assertEquals(844L, output.length())
        assertArrayEquals(original.copyOfRange(444, 1244), output.readBytes().copyOfRange(44, 844))
        assertArrayEquals(original, input.readBytes())
    }
    @Test fun replacingWithShorterTrimLeavesNoStaleTail() {
        val file = wav("replace.wav")
        WavEditor.trim16BitPcm(file, file, 100, 200)
        assertEquals(244L, file.length())
        RandomAccessFile(file, "r").use { it.seek(44); assertEquals(100, it.readUnsignedByte()) }
    }
    @Test fun invalidSelectionPreservesDestination() {
        val input = wav("source.wav"); val output = wav("existing.wav"); val before = output.readBytes()
        assertThrows(IllegalArgumentException::class.java) { WavEditor.trim16BitPcm(input, output, 1100, 1200) }
        assertArrayEquals(before, output.readBytes())
    }
    @Test fun truncatedInputCannotReplaceOriginal() {
        val input = wav("broken.wav")
        RandomAccessFile(input, "rw").use { it.setLength(200) }
        val before = input.readBytes()
        assertThrows(IllegalArgumentException::class.java) { WavEditor.trim16BitPcm(input, input, 0, 50) }
        assertArrayEquals(before, input.readBytes())
    }
    @Test fun handlesAdditionalOddSizedRiffChunk() {
        val input = wav("chunk.wav"); val bytes = input.readBytes()
        val extra = byteArrayOf(74, 85, 78, 75, 1, 0, 0, 0, 42, 0)
        val expanded = bytes.copyOfRange(0, 36) + extra + bytes.copyOfRange(36, bytes.size)
        val length = expanded.size - 8
        repeat(4) { expanded[4 + it] = (length ushr (it * 8)).toByte() }
        input.writeBytes(expanded)
        val output = folder.newFile("trim.wav")
        WavEditor.trim16BitPcm(input, output, 0, 100)
        assertArrayEquals(bytes.copyOfRange(44, 244), output.readBytes().copyOfRange(44, 244))
    }
    @Test fun clampsHugeEndTimeWithoutOverflow() {
        val input = wav("long.wav"); val output = folder.newFile("end.wav")
        WavEditor.trim16BitPcm(input, output, 900, Long.MAX_VALUE)
        assertEquals(244L, output.length())
    }
}
