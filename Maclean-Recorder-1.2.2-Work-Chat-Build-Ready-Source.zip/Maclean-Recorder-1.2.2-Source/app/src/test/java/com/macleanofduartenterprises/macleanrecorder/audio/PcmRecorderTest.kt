/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.audio

import com.macleanofduartenterprises.macleanrecorder.data.ChannelMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import kotlin.math.PI
import kotlin.math.sin

class PcmRecorderTest {
    @get:Rule val temporary = TemporaryFolder()

    @Test
    fun deviceAndMicrophonePcmIsMixedEvenly() {
        val device = pcm(20_000, -20_000, 32_000, -32_000)
        val microphone = pcm(10_000, 10_000, 32_000, -32_000)
        val output = ByteArray(device.size)

        mixPcm16(device, microphone, output, output.size)

        assertEquals(listOf(15_000, -5_000, 32_000, -32_000), samples(output))
    }

    @Test
    fun pureJavaEncoderProducesAnMp3Frame() {
        val file = temporary.newFile("recording.mp3")
        val rate = 44_100
        val frames = rate / 5
        val pcm = ByteArray(frames * 2)
        for (frame in 0 until frames) {
            val sample = (sin(2.0 * PI * 440.0 * frame / rate) * 12_000).toInt().toShort()
            pcm[frame * 2] = sample.toByte()
            pcm[frame * 2 + 1] = (sample.toInt() shr 8).toByte()
        }

        val sink = Mp3PcmSink(file, rate, ChannelMode.MONO, 192_000)
        pcm.asList().chunked(4096).forEach { chunk ->
            val bytes = chunk.toByteArray()
            sink.write(bytes, bytes.size - bytes.size.mod(2))
        }
        sink.finish()

        val encoded = file.readBytes()
        assertTrue("MP3 should contain encoded audio", encoded.size > 1_000)
        assertTrue("MP3 frame sync should be present", (0 until encoded.lastIndex).any { index ->
            (encoded[index].toInt() and 0xff) == 0xff &&
                (encoded[index + 1].toInt() and 0xe0) == 0xe0
        })
    }

    private fun pcm(vararg values: Int): ByteArray = ByteArray(values.size * 2).also { bytes ->
        values.forEachIndexed { index, value ->
            bytes[index * 2] = value.toByte()
            bytes[index * 2 + 1] = (value shr 8).toByte()
        }
    }

    private fun samples(bytes: ByteArray): List<Int> = bytes.asList().chunked(2).map { pair ->
        ((pair[0].toInt() and 0xff) or (pair[1].toInt() shl 8)).toShort().toInt()
    }
}
