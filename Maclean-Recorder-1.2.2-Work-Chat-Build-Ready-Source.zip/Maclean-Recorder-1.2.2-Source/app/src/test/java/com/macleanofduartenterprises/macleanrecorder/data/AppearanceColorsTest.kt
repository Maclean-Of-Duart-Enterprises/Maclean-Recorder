/* SPDX-License-Identifier: AGPL-3.0-only */
package com.macleanofduartenterprises.macleanrecorder.data

import org.junit.Assert.assertEquals
import org.junit.Test

class AppearanceColorsTest {
    @Test
    fun defaultsPreserveTheOriginalInterfacePalette() {
        val settings = RecorderSettings()

        assertEquals("#F3F6F2", settings.backgroundColorHex)
        assertEquals("#6750A4", settings.buttonColorHex)
        assertEquals("#79747E", settings.lineColorHex)
        assertEquals("#1D1B20", settings.letterColorHex)
    }

    @Test
    fun normalizeAcceptsSixDigitColorsAndCanonicalizesCase() {
        assertEquals("#A1B2C3", AppearanceColors.normalize("#a1b2c3", AppearanceColors.BUTTON))
    }

    @Test
    fun normalizeRejectsMalformedAndAlphaColors() {
        assertEquals(AppearanceColors.LINE, AppearanceColors.normalize("#ABC", AppearanceColors.LINE))
        assertEquals(AppearanceColors.LINE, AppearanceColors.normalize("#FF112233", AppearanceColors.LINE))
        assertEquals(AppearanceColors.LINE, AppearanceColors.normalize("not-a-color", AppearanceColors.LINE))
        assertEquals(AppearanceColors.LINE, AppearanceColors.normalize(null, AppearanceColors.LINE))
    }
}
