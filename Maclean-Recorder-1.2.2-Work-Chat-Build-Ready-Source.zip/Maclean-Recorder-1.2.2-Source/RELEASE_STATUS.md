# Maclean Recorder 1.2.2 release status

Maclean Recorder 1.2.2 was clean-built and signed with the supplied publisher key on 2026-10-02.
Release lint passed with zero errors and four documented nonblocking warnings; all 15 unit tests
passed. The signed APK's identity, v2/v3 signatures, alignment, license assets, launcher artwork,
and package contents were verified. The supplied launcher artwork is embedded byte-for-byte. An
MP3 produced by the compiled app sink was independently identified and decoded as 44.1 kHz mono
MP3 at 192 kbps.

The update replaces the app icon with the supplied green evergreen, sound-wave, and microphone
artwork. Adaptive masking, a matching dark-green edge fill, and an Android 13+ themed monochrome
companion are included. Default MP3 capture, all three recording-source choices, and independent
background, button, line, and letter color wheels are retained.

The APK contains no bundled native libraries, signing keys, AI models, or Internet permission.
No Android device or emulator was connected, so upgrade migration, launcher rendering, visual
interaction, startup, real microphone/device capture, notifications, and manufacturer codec
behavior still require the physical-device checks in `RELEASE_AUDIT.md`.
