# Maclean Recorder 1.2.2

Maclean Recorder is a local-first Android audio recorder for
`com.macleanofduartenterprises.macleanrecorder`. This release uses versionCode `10202`,
targets Android 15/API 35, supports Android 8.0/API 26 and later, and is licensed under
GNU AGPLv3 (`AGPL-3.0-only`).

## Highlights

- MP3 is available and is the default format. Encoding uses the bundled pure-Java Java LAME
  implementation, so it does not rely on a device-specific MP3 encoder or a native library.
- Recording source choices are **Device audio**, **Microphone**, and
  **Device + microphone**. Device capture requires Android 10 or later, displays Android's
  consent prompt for each session, and can only capture audio that the playing app permits.
- Device + microphone capture reads both sources concurrently and mixes them evenly into one file.
- The previous five background swatches are replaced by a continuous HSV color wheel with a
  brightness control and live hex preview.
- Button, line, and letter colors now have their own continuous color-wheel controls. Choices
  persist across restarts and are applied throughout the recorder, library, dialogs, and settings.
- The launcher now uses the supplied green evergreen, sound-wave, and microphone artwork, with
  adaptive masking and an Android 13+ themed monochrome companion.
- WAV, FLAC, M4A and Opus/Ogg remain available where the device supports them.

The app also includes an amplitude meter, microphone input selection, foreground/background
recording with a **Stop and save** notification, metadata, folders, tags, favorites, selected
deletion, FileProvider sharing/export, and 16-bit PCM WAV trimming. Appearance settings include
background photos, opacity, text scaling, high contrast, resettable interface colors, and
keep-screen-on. High contrast remains an accessibility override for custom interface colors.

Settings → Licenses displays the complete AGPLv3, third-party notices, and LGPLv3 text offline.
Java LAME source and its upstream reference are included under `third_party/java-lame/`.

## Build

Use JDK 17, Android SDK platform 35, build-tools 35.0.1, and the included Gradle 8.10.2 wrapper:

```sh
./gradlew clean lintRelease testReleaseUnitTest assembleRelease
python3 scripts/verify-apk.py app/build/outputs/apk/release/app-release-unsigned.apk
```

To create a publisher-signed build, follow `WORK_CHAT_BUILD.md`. Publisher keys and passwords
remain external to the source package.

`RELEASE_AUDIT.md` and `verification/` contain the build evidence, test results, lint output,
R8 mapping, APK identity, signature checks, and the device tests that still need to be run.

The APK has no Internet permission, bundled AI models, AI inference, transcription, JNI, or
native libraries. The waveform editor, built-in playback service, and advanced editing roadmap
are outside this release.
