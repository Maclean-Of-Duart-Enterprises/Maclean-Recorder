# Changelog

## 1.2.2 — 2026-10-02

- Replaced the launcher artwork with the supplied green evergreen, sound-wave, and microphone icon.
- Added adaptive-mask sizing, a matching dark-green edge fill, and a themed monochrome companion.
- Preserved the existing package identity, recorder features, preferences, and publisher key lineage.

## 1.2.1 — 2026-09-21

- Added independent continuous color-wheel settings for button, line, and letter colors.
- Applied custom colors to buttons and controls, text and icons, dividers, outlines, navigation,
  and the recording level line.
- Added persistent validated color preferences, live swatches, and a reset-to-defaults action.
- Kept high-contrast mode as an explicit accessibility override for custom interface colors.

## 1.2.0 — 2026-09-20

- Added MP3 recording and made MP3 the default format.
- Added Device audio, Microphone, and Device + microphone recording sources.
- Added Android MediaProjection consent and foreground-service support for playback capture.
- Added concurrent device/microphone capture with balanced PCM mixing.
- Replaced the five background swatches with a continuous HSV color wheel and brightness control.
- Added bundled pure-Java Java LAME source, LGPLv3 text, attribution, MP3 tests, and release checks.

## 1.1.0 — 2026-09-09

- Corrected and verified the foreground recording, audio encoding, routing, WAV editing, library,
  appearance, licensing, build, and signing workflows in the supplied source.
