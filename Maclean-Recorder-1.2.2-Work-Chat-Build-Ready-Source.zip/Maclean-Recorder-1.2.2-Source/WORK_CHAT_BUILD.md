# Maclean Recorder 1.2.2 — build and signing

Preserve application ID `com.macleanofduartenterprises.macleanrecorder`, versionName `1.2.2`,
versionCode `10202`, minSdk 26, and compile/target SDK 35. Do not place publisher passwords or
private keys in the project or source ZIP.

## Requirements

- JDK 17
- Android SDK platform 35 and build-tools 35.0.1
- Python 3
- Access to the official Gradle, Google Maven, and Maven Central repositories for a first build

The wrapper pins Gradle 8.10.2 and its distribution checksum. The project uses AGP 8.7.3 and
Kotlin 2.0.21. AndroidX versions are intentionally selected so the APK remains free of bundled
JNI libraries.

Set `ANDROID_HOME` or `ANDROID_SDK_ROOT` to the Android SDK, then build and verify an unsigned APK:

```sh
./gradlew clean lintRelease testReleaseUnitTest assembleRelease
python3 scripts/verify-apk.py app/build/outputs/apk/release/app-release-unsigned.apk
```

Build and sign with the separately supplied publisher key:

```sh
MACLEAN_KEYSTORE=/absolute/path/to/release.keystore scripts/build-release.sh
```

The script uses `signature/release.keystore` when `MACLEAN_KEYSTORE` is omitted. It prompts
privately for the store and key passwords. Automated environments may provide
`MACLEAN_STORE_PASSWORD` and `MACLEAN_KEY_PASSWORD` as protected environment variables.
`MACLEAN_KEY_ALIAS` defaults to `macleanphonerelease`.

The script performs a clean build, release lint, all 15 unit tests, R8 release assembly,
zip alignment, publisher signing, signature verification, APK content checks, and SHA-256
generation. `scripts/verify-apk.py` rejects native libraries, AI model formats, and signing
keys, and confirms that the AGPLv3, third-party, and LGPLv3 assets exactly match their sources.

Before publication, install the signed APK on physical Android devices and complete the checks
listed in `RELEASE_AUDIT.md`. Device playback capture requires Android 10 or later and a fresh
Android MediaProjection consent for every recording session.
