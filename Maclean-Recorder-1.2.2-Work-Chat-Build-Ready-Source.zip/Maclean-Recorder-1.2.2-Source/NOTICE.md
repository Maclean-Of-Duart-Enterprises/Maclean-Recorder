# Attribution / design references
Maclean Recorder is an original clean-room implementation.
Design research considered public feature/architecture descriptions from Daedalus Echo, Recording Studio, and Dimowner AudioRecorder. No source code from those projects is incorporated in this package.
