#!/usr/bin/env python3
"""SPDX-License-Identifier: AGPL-3.0-only. Check required release contents."""
import argparse
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('apk', type=Path)
args = parser.parse_args()
project = Path(__file__).resolve().parent.parent
with zipfile.ZipFile(args.apk) as apk:
    bad = apk.testzip()
    if bad:
        raise SystemExit(f'APK contains a damaged entry: {bad}')
    forbidden = [name for name in apk.namelist() if name.startswith('lib/') or
                 name.lower().endswith(('.so', '.keystore', '.jks', '.gguf', '.ggml'))]
    if forbidden:
        raise SystemExit('Release contains excluded native libraries, models, or keys: ' + ', '.join(forbidden))
    for asset, source in [('assets/licenses/AGPL-3.0.txt', 'LICENSE'),
                          ('assets/licenses/THIRD-PARTY-NOTICES.txt', 'THIRD-PARTY-NOTICES.txt'),
                          ('assets/licenses/LGPL-3.0.txt', 'third_party/java-lame/LICENSE')]:
        if apk.read(asset) != (project / source).read_bytes():
            raise SystemExit('Offline license text does not match its source: ' + asset)
    if not any(name.endswith('.dex') for name in apk.namelist()):
        raise SystemExit('APK has no compiled application code.')
print('APK contents verified: compiled code, exact offline licenses, no bundled native libraries/models/keys.')
