#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-only
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
sdk_dir="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$sdk_dir" ]]; then
    echo 'Set ANDROID_HOME to an Android SDK with platform 35 and build-tools 35.0.1.' >&2
    exit 1
fi
keystore_path="${MACLEAN_KEYSTORE:-$project_dir/signature/release.keystore}"
key_alias="${MACLEAN_KEY_ALIAS:-macleanphonerelease}"
[[ -f "$keystore_path" ]] || { echo "Signing keystore not found: $keystore_path" >&2; exit 1; }
if [[ -z "${MACLEAN_STORE_PASSWORD:-}" ]]; then
    read -r -s -p 'Keystore password: ' MACLEAN_STORE_PASSWORD
    echo
fi
if [[ -z "${MACLEAN_KEY_PASSWORD:-}" ]]; then
    read -r -s -p 'Key password: ' MACLEAN_KEY_PASSWORD
    echo
fi
export MACLEAN_STORE_PASSWORD MACLEAN_KEY_PASSWORD
trap 'unset MACLEAN_STORE_PASSWORD MACLEAN_KEY_PASSWORD' EXIT
./gradlew clean lintRelease testReleaseUnitTest assembleRelease
mkdir -p release
unsigned=app/build/outputs/apk/release/app-release-unsigned.apk
aligned=release/aligned-unsigned.apk
apk=release/Maclean-Recorder-1.2.2-Signed.apk
"$sdk_dir/build-tools/35.0.1/zipalign" -f -P 16 4 "$unsigned" "$aligned"
"$sdk_dir/build-tools/35.0.1/apksigner" sign --ks "$keystore_path" --ks-key-alias "$key_alias" \
    --ks-pass env:MACLEAN_STORE_PASSWORD --key-pass env:MACLEAN_KEY_PASSWORD --out "$apk" "$aligned"
"$sdk_dir/build-tools/35.0.1/apksigner" verify --verbose --print-certs "$apk"
"$sdk_dir/build-tools/35.0.1/zipalign" -c -P 16 4 "$apk"
python3 scripts/verify-apk.py "$apk"
rm "$aligned"
(cd release && sha256sum "$(basename "$apk")" > SHA256SUMS.txt)
